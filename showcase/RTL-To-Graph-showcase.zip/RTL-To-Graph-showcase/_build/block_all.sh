#!/usr/bin/env bash
# 1) 編譯 NDEBUG 版的 adaptagrams（avoid_run_nd 用）  2) 用最終提交的程式跑 30 個設計的架構圖
set -uo pipefail
SPW="$1"
T="$HOME/rtl2d-demo/repo/runs/.tools"
R="$HOME/rtl2d-demo/branchcheck_1692baf"
LOG="$HOME/rtl2d-demo/reg/block_all.log"; : > "$LOG"
if [ ! -d "$T/adaptagrams-nd/lib" ]; then
  [ -d "$T/src/adaptagrams-nd" ] || cp -r "$T/src/adaptagrams" "$T/src/adaptagrams-nd"
  ( cd "$T/src/adaptagrams-nd/cola" && make distclean >/dev/null 2>&1; ./configure --prefix="$T/adaptagrams-nd" CXXFLAGS="-O2 -DNDEBUG" >/dev/null 2>&1 && make -j6 >/dev/null 2>&1 && make install >/dev/null 2>&1 ) && echo "nd build ok" >> "$LOG" || echo "nd build FAILED" >> "$LOG"
fi
( cd "$HOME/rtl2d-demo/repo" && sh layers/l3_draw/experiments/e3_paper_engines/native/build.sh 2>&1 | tail -1 ) >> "$LOG"
ls "$T/bin" >> "$LOG"
mkdir -p "$R/runs"; [ -e "$R/runs/.tools" ] || ln -s "$T" "$R/runs/.tools"
cp "$HOME/rtl2d-demo/repo/runs/gallery_manifest.json" "$R/runs/gallery_manifest.json"
cd "$R"
export GAL_ROOT="$R" GAL_OUT="runs/gallery_block"
RUN="uv run --package rtl2d-l1 --with nodejs-wheel --with ortools python"
for n in $(python3 -c "import json; print(' '.join(e['name'] for e in json.load(open('runs/gallery_manifest.json'))))"); do
  $RUN "$SPW/build/gal_block2.py" A "$n" - busbar,dot,hola,grid 2>&1 | grep -v "^ *Downloaded\|^Installed\|^ *Built\|^Resolved" | tail -1 | cut -c1-300 >> "$LOG"
  $RUN "$SPW/build/gal_block2.py" B "$n" 2>&1 | tail -1 | cut -c1-200 >> "$LOG"
done
echo ALLDONE >> "$LOG"
