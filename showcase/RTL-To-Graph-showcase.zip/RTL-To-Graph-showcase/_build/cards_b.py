# 狀態機圖的對照卡片、總評，並輸出 cards.json
import io, json, os, sys

S = os.environ["GAL_S"]
sys.path.insert(0, os.path.dirname(__file__))
from cards_a import cards, off, tm  # noqa: E402

NOFSM = "官方文件沒有這個模組的狀態機圖。"

cards.append({
    "id": "f_serv", "kind": "fsm", "verdict": "fail", "project": "olofk/serv", "title": "SERV 的指令生命週期",
    "official": [off("olofk_serv", "life_cycle.png", "SERV 官方的指令生命週期流程圖：Fetch、Decode、是否有中斷、是否為兩階段運算、Init、Execute、Trap、Retire", "官方流程圖，說明一道指令經過哪些階段。", "olofk/serv", "doc/life_cycle.png", "ISC")],
    "ours": [], "ours_none": "serv_state 模組沒有抽出任何狀態機，也沒有時序圖。",
    "ours_how": "未修改，已開啟計數器驅動狀態機的選項",
    "good": ["沒有硬湊出一張錯的圖。"],
    "gap": ["serv_top 補上越界檢查後不再當掉，但沒有認出任何介面，一樣沒有圖。", "SERV 是位元序列處理器，它的「狀態」由一個計數器加上幾個旗標共同決定，不是單一狀態暫存器。目前的抽取方式找不到。", "官方圖畫的是設計者腦中的階段，這種跨多個暫存器的抽象狀態，是最難自動還原的一類。"],
    "next": ["支援由多個暫存器組合出的狀態：先找出互斥的旗標組，再合成一個抽象狀態。", "短期內可以退一步：至少把 init、cnt_en、cnt_done 這幾個訊號畫成時序圖。"],
})

cards.append({
    "id": "f_picorv32", "kind": "fsm", "verdict": "none", "project": "YosysHQ/picorv32", "title": "PicoRV32 的主狀態機與記憶體介面狀態機",
    "official": [], "official_none": NOFSM + "README 只有文字說明。",
    "ours": [tm("x4f/fsm__picorv32.cpu_state.svg", "RTL-To-Graph 抽出的 picorv32 cpu_state 狀態機：fetch、ld_rs1、ld_rs2、exec、shift、stmem、ldmem、trap 八個狀態", "cpu_state｜one-hot 編碼，8 個狀態、21 條轉移，狀態名直接取自 RTL。"),
             tm("x4f/fsm__picorv32.mem_state.svg", "RTL-To-Graph 抽出的 picorv32 mem_state 狀態機：四個狀態", "mem_state｜4 個狀態、6 條轉移，Yosys 交叉比對一致。")],
    "ours_how": "未修改，直接出圖",
    "stats": "3,049 行的單一檔案，64 秒完成。這台機器沒有 SymbiYosys，完整性證明沒有跑。",
    "good": ["one-hot 編碼照樣抽得出來，而且八個狀態都用 RTL 裡的名字：cpu_state_fetch、cpu_state_exec 等。", "轉移條件直接寫在邊上，例如 is_sb_sh_sw、instr_trap。", "官方完全沒有這張圖，三千行的 always 區塊只能自己讀。"],
    "gap": ["有四個狀態畫成灰色虛線，表示從重置出發沒有走到。它們其實是合法狀態，是取樣沒覆蓋到。", "cpu_state 和 Yosys 的結果不一致，專案紀錄已知：多出來的邊是參數關閉的路徑。", "mem_state 的狀態只有 0 到 3，因為 RTL 本身就用數字，讀者還是不知道各代表什麼。", "條件太長的被截斷成刪節號。"],
    "next": ["未走到的狀態，用形式工具補一次可達性檢查，再決定畫實線或標示為不可達。", "沒有名字的狀態，用它驅動的輸出訊號自動命名。", "長條件改成編號，圖下方列對照表。"],
})

cards.append({
    "id": "f_i2c", "kind": "fsm", "verdict": "none", "project": "alexforencich/verilog-i2c", "title": "I2C 主控端的兩層狀態機",
    "official": [], "official_none": "這個專案整個 repo 沒有任何圖。",
    "ours": [tm("x4f/fsm__i2c_master.state_reg.svg", "RTL-To-Graph 抽出的 i2c_master 上層狀態機：IDLE、ACTIVE_WRITE、ACTIVE_READ、START_WAIT、START、ADDRESS_1、ADDRESS_2、WRITE_1 到 WRITE_3、READ、STOP", "上層 state_reg｜12 個狀態、37 條轉移。"),
             tm("x4f/fsm__i2c_master.phy_state_reg.svg", "RTL-To-Graph 抽出的 i2c_master 實體層狀態機：16 個 PHY_STATE 狀態", "實體層 phy_state_reg｜16 個狀態、35 條轉移。")],
    "ours_how": "未修改，直接出圖",
    "stats": "37 秒完成，兩個狀態機都保留 RTL 的狀態名。",
    "good": ["一個模組裡的兩層狀態機都找到了，沒有混在一起。", "狀態名完整保留：STATE_ADDRESS_1、PHY_STATE_WRITE_BIT_2 等。"],
    "gap": ["超過十個狀態之後，版面橫向拉得很開，字小到要放大才看得見。", "幾乎每個狀態都有一條回到 IDLE 的邊，十幾條長弧線蓋住了主要流程。", "實體層有一半的狀態是灰色，沒有從重置走到。"],
    "next": ["「任何狀態都可回到 IDLE」這種共同轉移，合併成一個標記，不要每條都畫。", "十個狀態以上改用分層或分群的排版。專案計畫裡已列為待辦。"],
})

cards.append({
    "id": "f_rejected", "kind": "fsm", "verdict": "fail", "project": "ZipCPU/wb2axip、YosysHQ/picorv32", "title": "被自己的檢查擋下的兩個狀態機",
    "official": [], "official_none": NOFSM,
    "ours": [tm("x4f/fsm_rejected__axisgfsm.sgstate.svg", "被判定為拒絕的 axisgfsm sgstate 狀態機：SG_IDLE、SG_SRCHALF、SG_SRCADDR、SG_DSTHALF、SG_DSTADDR、SG_LENGTH、SG_CONTROL、SG_WAIT", "axisgfsm.sgstate｜8 個狀態、18 條轉移。圖是對的，但被標成拒絕。"),
             tm("x4f/fsm_rejected__spimemio.state.svg", "被判定為拒絕的 spimemio state 狀態機：13 個狀態、51 條轉移", "spimemio.state｜13 個狀態、51 條轉移，同樣被拒絕。"),
             tm("x4f/fixed__axisgfsm.sgstate.svg", "修正後通過檢查的 axisgfsm sgstate 狀態機", "修正後 axisgfsm｜通過檢查，判定為一致的子集。"),
             tm("x4f/fixed__spimemio.state.svg", "修正後通過檢查的 spimemio state 狀態機，13 個狀態全部走到", "修正後 spimemio｜通過檢查，13 個狀態全部走到，判定為一致。")],
    "ours_how": "未修改；這兩張是從「拒絕」資料夾撈出來的",
    "stats": "拒絕原因都是語意檢查回報「不支援的常數」。",
    "good": ["寧可拒絕也不放行沒驗證過的圖，這個原則是對的。", "axisgfsm 那張其實畫得很好，狀態名、條件都齊全。"],
    "gap": ["兩個都是模組裡最重要的狀態機，卻沒有進到正式輸出。", "原因很小：語意檢查的常數解析不接受 Verilog 合法的寫法。一個是基底後面有空白，例如 1'b 0；一個是含問號的萬用字元，例如 3'b 01?；一個是常數前面夾了註解。", "spimemio 還多了一個問題：找不到重置狀態。"],
    "next": ["兩個都已在分支 fix/l1-timing-oob-fsm-const 修正，切到「修正後」的分頁可以看結果。", "axisgfsm 只需要常數解析的修正。spimemio 還需要另外兩項：重置條件寫成「reset 或 softreset」時也要認得重置狀態；狀態要等子模組的 din_ready，隨機取樣出現的機率約千分之一，改成先找出能讓它成立的訊號組合，再在每個狀態重播。"],
})

cards.append({
    "id": "f_counter", "kind": "fsm", "verdict": "none", "project": "YosysHQ/picorv32、alexforencich/verilog-uart", "title": "UART 接收端：計數器被畫成一長串狀態",
    "official": [], "official_none": NOFSM,
    "ours": [tm("x4f/fsm__simpleuart.recv_state.svg", "RTL-To-Graph 抽出的 simpleuart recv_state：S_0 到 S_10 排成一條鏈", "simpleuart.recv_state｜11 個狀態排成一條鏈。"),
             tm("x4f/fsm__uart_rx.bit_cnt.svg", "RTL-To-Graph 抽出的 uart_rx bit_cnt：S_0 到 S_10 排成一條鏈", "uart_rx.bit_cnt｜位元計數器，同樣是 11 個狀態的鏈。")],
    "ours_how": "未修改，已開啟計數器驅動狀態機的選項",
    "stats": "兩者都只通過語意檢查，Yosys 不認為它們是狀態機。",
    "good": ["不靠 case 敘述也找得到：這兩個都是用數值比較寫的。", "轉移條件正確，例如等鮑率計數到底才前進。"],
    "gap": ["人畫這張圖只會畫三個狀態：等待起始位元、接收八個位元、停止位元。我們把計數器的每個值都攤開成一個狀態。", "狀態沒有名字，只有 S_0 到 S_10。"],
    "next": ["偵測「連續遞增、條件相同」的狀態鏈，摺成一個帶次數的狀態。", "這和架構圖已經做的「重複單元摺疊」是同一個想法。"],
})

cards.append({
    "id": "f_phantom", "kind": "fsm", "verdict": "fail", "project": "ZipCPU/wb2axip", "title": "誤判：一個位元的旗標被當成狀態機",
    "official": [], "official_none": "這不是狀態機，官方當然沒有圖。",
    "ours": [tm("x4f/fsm__axidma.phantom_write.svg", "被誤判為狀態機的 axidma phantom_write：只有一個狀態和一條自迴圈", "axidma.phantom_write｜1 個狀態、1 條轉移。"),
             tm("x4f/fsm__axivfifo.phantom_read.svg", "被誤判為狀態機的 axivfifo phantom_read：兩個狀態", "axivfifo.phantom_read｜2 個狀態、4 條轉移。")],
    "ours_how": "未修改，直接出圖",
    "stats": "wb2axip 的三個模組共出現 5 個這種旗標，其中 4 個通過檢查。",
    "good": ["其中一個被語意檢查擋下。"],
    "gap": ["phantom_write、phantom_read、phantom_start 是記錄「已送出但尚未成交」的一位元旗標，不是狀態機。", "只有一個狀態的圖沒有任何資訊，卻通過了全部檢查並出現在正式輸出裡。", "同一個旗標還被選進時序圖當內部訊號，佔掉更有意義的訊號的位置。"],
    "next": ["狀態數少於三個、或位寬只有一位元的候選，預設不當成狀態機。", "專案裡已經有三條過濾規則，這是第四條。"],
})

# ───────── 統計 ─────────
import glob

eng_ok = eng_err = rt = 0
blk_designs = 0
for f in glob.glob(os.path.join(S, "blk", "*", "block.json")):
    b = json.load(open(f, encoding="utf-8"))
    blk_designs += 1
    for e in b["engines"].values():
        if e["status"] == "ok":
            eng_ok += 1
            rt += e.get("roundtrip", 0)
        else:
            eng_err += 1
res = json.load(io.open(os.path.join(S, "x4f", "results.json"), encoding="utf-8"))
n_des = len(res)
n_crash = sum(1 for d in res if any("e9.select" in str(x) for x in d["errors"]))
n_tim = sum(len(d["timing"]) for d in res)
n_tim_des = sum(1 for d in res if d["timing"])
patched = []
for name in ("x4p", "x4p2"):
    p = os.path.join(S, name, "results.json")
    if os.path.exists(p):
        patched += json.load(io.open(p, encoding="utf-8"))
p_des = sum(1 for d in patched if d["timing"])
p_tim = sum(len(d["timing"]) for d in patched)
p_quiet = sum(1 for d in patched if not d["timing"] and not d["errors"])
p_sim = sum(1 for d in patched if not d["timing"] and d["errors"])
p_chk = all(all(v is True or (isinstance(v, dict) and v.get("ok")) for v in t.get("checks", {}).values()) for d in patched for t in d["timing"])
stats = dict(eng_ok=eng_ok, eng_err=eng_err, rt=rt, blk_designs=blk_designs, n_des=n_des, n_crash=n_crash, n_tim=n_tim,
             n_tim_des=n_tim_des, p_des=p_des, p_tim=p_tim, p_total=len(patched), p_chk=p_chk)
print(stats)

kinds = {k: sum(1 for c in cards if c["kind"] == k) for k in ("block", "timing", "fsm")}
summary = {
    "title": "RTL-To-Graph 對照圖廊",
    "lead": "拿五個開源專案的 RTL 餵給我們的工具，再把產生的圖和這些專案自己文件裡的官方圖並排。做得好的、做不好的、直接失敗的，全部照實放上來。30 個設計的架構圖、狀態機圖、時序圖全部成果與評估在 <a href=\"all.html\" style=\"color:#fff\"><b>完整成果頁</b></a>。",
    "chips": [[str(len(cards)), "組對照"], ["5", "個開源專案"], [str(kinds["block"]), "組架構圖"], [str(kinds["timing"]), "組時序圖"], [str(kinds["fsm"]), "組狀態機圖"]],
    "boxes": [
        {"title": "一句話結論", "cls": "s12 lead", "html": "<p>系統層級的架構圖已經接近官方水準。處理器的資料路徑、模組內部、以及交易層級的時序圖，官方手繪仍然明顯較好。</p><p>工具最有價值的地方，是官方根本沒畫的那些模組：這次挑的設計裡，狀態機圖官方只有一張，我們能畫出一批。</p>"},
        {"title": "做得好的", "cls": "s6", "html": f"<ul><li><b>架構圖全部產出且接線正確</b>：{blk_designs} 個設計、{eng_ok} 張圖，從 SVG 反查回規格共 {rt} 個錯誤。每張排版都在 2 秒內。</li><li><b>SoC 頂層對得上官方圖</b>：PicoSoC、DarkSoCV、serv_rf_top 的單元和官方圖一一對應，還多畫出官方省略的位址解碼與時脈重置。</li><li><b>簡單交握介面的時序圖</b>：skidbuffer、非同步 FIFO 這一類，情境選得對，因果箭頭與時脈域分組是官方圖沒有的。</li><li><b>有名字的狀態機</b>：PicoRV32 的 one-hot 主狀態機、I2C 的兩層狀態機，狀態名都直接取自 RTL。</li></ul>"},
        {"title": "和官方圖的主要差距", "cls": "s6", "html": "<ul><li><b>架構圖只有一種抽象層級</b>。官方圖會挑重點、依管線階段排、把內層的重要模組拉出來、替匯流排命名。我們把連線全畫，遇到單一大模組的處理器或密集的模組就變成一團線，交叉數從 22 到 121。</li><li><b>時序圖停在單一通道</b>。官方圖講的是一筆交易從進到出；我們每個通道一張，隨機刺激、原始數值、視窗只有五六個週期，橋接類模組的重點完全看不到。</li><li><b>狀態機有三種失誤</b>：正確的圖被常數解析擋下、一位元旗標被誤認成狀態機、計數器被攤成一長串狀態。SERV 這種由多個暫存器組合出的狀態則完全抽不到。</li></ul>"},
        {"title": "穩定性", "cls": "s6", "order": 4, "html": f"<ul><li>時序圖這一步，{n_des} 個設計裡有 <b>{n_crash} 個直接當掉</b>，全部是同一行：多檔案設計裡，行號被拿去查錯的檔案而越界。原始程式只在 {n_tim_des} 個設計上產生 {n_tim} 張時序圖。</li><li>在本機副本補上一行越界檢查後，這 {n_crash} 個都不再當掉：{p_des} 個出圖，共 {p_tim} 張，五項檢查{'全數通過' if p_chk else '未全數通過'}；{p_quiet} 個沒有認出任何介面，所以沒有圖；{p_sim} 個卡在模擬，需要這台沒裝的 Verilator。圖廊裡標示「補一行」的就是這批。</li><li><b>後續已修正並推上 GitHub</b>：分支 <code>fix/l1-timing-oob-fsm-const</code>，兩個提交，既有分支沒有被更動。修掉的有：多檔案越界、常數解析、註解混進狀態名、與 reset 並列的 soft reset 認不出重置狀態、等子模組交握的狀態走不到、模擬器的巨集互相干擾。用修正後的程式重跑同樣的設計：當掉的由 12 個降為 0 個；時序圖由 52 張增加到 174 張，能出圖的設計由 12 個增加到 21 個，五項檢查全數通過；狀態機通過的由 16 個增加到 18 個，被拒絕的由 3 個降為 1 個。spimemio 的主狀態機 13 個狀態全部走到，picosoc 可以用 iverilog 模擬。執行時間增加約兩成。</li><li>架構圖引擎有 {eng_err} 次失敗，原因是繞線庫的斷言；另一個除錯版本的繞線庫這次沒有編譯。</li><li>APB 介面完全不認得，apbxclk 沒有任何輸出。</li></ul>"},
        {"title": "改進方向，依投入與回報排序", "cls": "s12 two", "order": 3, "html": f"<ol><li><b>先修兩個確定的錯誤</b>。時序圖的越界檢查，以及狀態機語意檢查的常數解析。兩個都是小改動，前者讓能畫出時序圖的設計從 {n_tim_des} 個增加到 {n_tim_des + p_des} 個，後者救回被誤擋的狀態機。</li><li><b>時序圖升級到交易層級</b>。同一筆交易的請求與回應畫在同一張；自動產生的測試平台替下游接上會回應的模型；資料改用 A0、D0 這種符號並依交易上色。</li><li><b>架構圖加上連線標籤與「只看資料」的檢視</b>。介面名稱、位寬寫在線上；用 L1 已有的重要度分數濾掉控制線；只被一個方塊使用的介面畫在該方塊旁。</li><li><b>資料路徑畫法</b>。單一大模組的處理器依管線階段分欄。需要繞線器支援上下進出的埠，專案紀錄裡已排在第一。</li><li><b>補介面樣板</b>：APB、Wishbone 主端；AXI 五個通道合成一個介面。</li><li><b>狀態機後處理</b>：濾掉一位元旗標、把計數鏈摺成一個狀態、共同的回 IDLE 轉移合併、十個狀態以上換排版。</li><li><b>把這份對照變成回歸測試</b>。官方圖就是現成的標準答案，每次改版重跑一次，看哪幾組的結論變了。</li></ol>"},
        {"title": "讀這份對照前要知道的事", "cls": "s6", "order": 5, "html": "<ul><li>每組的結論是 Claude 逐張看圖後的判斷，只有一位評審，不是盲測。請當成一份審稿意見，而不是量測結果。</li><li>架構圖的單元命名來自 repo 內既有的 teacher 標註；biRISC-V 頂層沒有標註，用的是規則式標註。</li><li>RTL 用的是 repo 內附的快照，官方圖取自各專案目前的主分支，兩者版本可能略有出入。</li><li>這台機器沒有 SymbiYosys，狀態機的完整性證明沒有跑；模擬器是 iverilog 12.0。</li><li>點任何一張圖可以放大，按 Esc 關閉。我們的圖上方有分頁可以切換不同的排版引擎或情境。</li></ul>"},
    ],
    "footer": "工具原始輸出的完整圖集：<a href=\"raw/x4_fixed.html\"><b>修正後的 30 個設計，174 張時序圖與 19 個狀態機</b></a>、<a href=\"raw/x4_original.html\">未修改的 29 個設計</a>、<a href=\"raw/x4_patched_a.html\">補一行後的第一批</a>、<a href=\"raw/x4_patched_b.html\">補一行後的第二批</a>。<br>官方圖的著作權屬於各專案作者，依其開源授權引用，來源與授權標示在每張圖下方：olofk/serv（ISC）、YosysHQ/picorv32（ISC）、darklife/darkriscv（BSD-3-Clause）、ultraembedded/biriscv（Apache-2.0）、ZipCPU/wb2axip（Apache-2.0）。<br>我們的圖於 2026 年 11 月 16 日在本機 WSL 以 <code>feat/fsm-timing</code> 分支產生。架構圖走 L1 前端、teacher-v1 標註、x1 bridge、x2 adapter、e3 排版引擎與 libavoid 繞線；狀態機圖與時序圖走 x4 管線。",
}
json.dump({"summary": summary, "cards": cards}, io.open(os.path.join(S, "cards.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
v = {}
for c in cards:
    v[c["verdict"]] = v.get(c["verdict"], 0) + 1
print("cards", len(cards), kinds, v)
