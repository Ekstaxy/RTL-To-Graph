"""把 cards.json + 圖檔組成可直接雙擊開啟的靜態 gallery。
    python make_gallery.py <cards.json> <scratch_dir> <out_dir>
圖檔路徑在 cards.json 內以 scratch_dir 為基準；輸出時複製到 out_dir/assets/ 下。"""
import html, io, json, os, shutil, sys

cards_path, scratch, out = sys.argv[1], sys.argv[2], sys.argv[3]
data = json.load(io.open(cards_path, encoding="utf-8"))
os.makedirs(os.path.join(out, "assets"), exist_ok=True)


def asset(rel):
    """複製圖檔並回傳 gallery 內的相對路徑。"""
    src = os.path.join(scratch, rel)
    if not os.path.exists(src):
        raise SystemExit(f"missing asset: {rel}")
    dst_rel = "assets/" + rel.replace("\\", "/")
    dst = os.path.join(out, dst_rel)
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copyfile(src, dst)
    return dst_rel


for c in data["cards"]:
    for o in c.get("official", []):
        o["src"] = asset(o["src"])
    for o in c.get("ours", []):
        o["src"] = asset(o["src"])

KIND = {"block": "架構圖", "timing": "時序圖", "fsm": "狀態機圖"}
VERDICT = {"ours": "我們較清楚", "tie": "各有所長", "theirs": "官方較好", "none": "官方沒畫", "fail": "我們失敗"}
counts = {}
for c in data["cards"]:
    counts[c["verdict"]] = counts.get(c["verdict"], 0) + 1
kinds = {}
for c in data["cards"]:
    kinds[c["kind"]] = kinds.get(c["kind"], 0) + 1

esc = html.escape
CSS = r"""
:root{--bg:#f3f4f6;--card:#fff;--ink:#14171c;--mute:#5b6370;--line:#d9dde3;--block:#2563eb;--timing:#c2410c;--fsm:#047857;
--ours:#047857;--tie:#6b7280;--theirs:#b91c1c;--none:#7c3aed;--fail:#b91c1c}
*{box-sizing:border-box}html{scroll-behavior:smooth}
body{margin:0;background:var(--bg);color:var(--ink);font:17px/1.75 "Microsoft JhengHei","Noto Sans TC","PingFang TC",system-ui,sans-serif}
header.hero{background:#0b0d10;color:#fff;padding:56px 24px 44px}
.wrap{max-width:1500px;margin:0 auto;padding:0 24px}
.hero h1{font-size:44px;line-height:1.25;margin:0 0 12px;letter-spacing:.01em}
.hero p{font-size:20px;color:#b6bcc6;margin:0 0 22px;max-width:60em}
.chips{display:flex;flex-wrap:wrap;gap:10px}
.chip{border:1px solid #3a4049;border-radius:999px;padding:6px 16px;font-size:16px;color:#e6e8eb}
.chip b{font-size:20px;margin-right:6px;color:#fff}
section.sum{padding:36px 0 8px}
h2{font-size:30px;margin:0 0 16px;line-height:1.3}
.cols{display:grid;grid-template-columns:repeat(12,1fr);gap:18px}
.box{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:22px 24px;grid-column:span 4}
.box.s12{grid-column:span 12}.box.s8{grid-column:span 8}.box.s6{grid-column:span 6}
.box.lead p{font-size:21px;line-height:1.7;max-width:46em}
.box.two ol{columns:2;column-gap:48px}.box.two li{break-inside:avoid}
@media (max-width:1100px){.box,.box.s8,.box.s6{grid-column:span 12}}
.box h3{margin:0 0 10px;font-size:21px}
.box ul,.box ol{margin:0;padding-left:1.3em}.box li{margin:.35em 0}
.box p{margin:.4em 0}
.score{display:flex;flex-wrap:wrap;gap:12px;margin:0 0 20px}
.score div{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:12px 20px;min-width:150px}
.score b{display:block;font-size:34px;line-height:1.1}
.score span{font-size:16px;color:var(--mute)}
nav.filter{position:sticky;top:0;z-index:5;background:rgba(243,244,246,.94);backdrop-filter:blur(6px);border-bottom:1px solid var(--line);padding:12px 0;margin-top:28px}
nav.filter .wrap{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
nav.filter span.lab{font-size:16px;color:var(--mute);margin:0 4px 0 10px}
button.f{font:inherit;font-size:16px;border:1px solid var(--line);background:#fff;border-radius:999px;padding:5px 16px;cursor:pointer;color:var(--ink)}
button.f[aria-pressed=true]{background:#14171c;color:#fff;border-color:#14171c}
article.card{background:var(--card);border:1px solid var(--line);border-radius:16px;margin:22px 0;overflow:hidden}
.card>header{display:flex;flex-wrap:wrap;gap:10px 14px;align-items:center;padding:18px 24px;border-bottom:1px solid var(--line)}
.card h3{font-size:25px;margin:0;line-height:1.3;flex:1 1 320px}
.tag{font-size:15px;border-radius:999px;padding:3px 13px;color:#fff;white-space:nowrap}
.tag.block{background:var(--block)}.tag.timing{background:var(--timing)}.tag.fsm{background:var(--fsm)}
.tag.v-ours{background:var(--ours)}.tag.v-tie{background:var(--tie)}.tag.v-theirs{background:var(--theirs)}.tag.v-none{background:var(--none)}.tag.v-fail{background:var(--fail)}
.pair{display:grid;grid-template-columns:1fr 1fr;gap:0}
.pane{padding:18px 22px;min-width:0}.pane+.pane{border-left:1px solid var(--line)}
.pane h4{margin:0 0 10px;font-size:19px;display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.pane h4 small{font-weight:400;font-size:16px;color:var(--mute)}
figure{margin:0 0 14px}
figure img{display:block;width:100%;height:auto;max-height:560px;object-fit:contain;margin:0 auto;background:#fff;border:1px solid var(--line);border-radius:8px;cursor:zoom-in}
figcaption{font-size:16px;color:var(--mute);margin-top:6px}
figcaption a{color:inherit}
.empty{border:2px dashed var(--line);border-radius:10px;padding:34px 20px;text-align:center;color:var(--mute);font-size:18px}
.tabs{display:flex;flex-wrap:wrap;gap:6px;margin:0 0 10px}
.tabs button{font:inherit;font-size:16px;border:1px solid var(--line);background:#fff;border-radius:8px;padding:3px 12px;cursor:pointer}
.tabs button[aria-selected=true]{background:#14171c;color:#fff;border-color:#14171c}
.stats{font-size:16px;color:var(--mute);margin:-4px 0 0}
.notes{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:0;border-top:1px solid var(--line)}
.notes div{padding:16px 22px}.notes div+div{border-left:1px solid var(--line)}
.notes h5{margin:0 0 6px;font-size:17px;color:var(--mute);letter-spacing:.04em}
.notes ul{margin:0;padding-left:1.2em}.notes li{margin:.3em 0}
footer{padding:30px 0 60px;color:var(--mute);font-size:16px}footer a{color:var(--ink)}
footer code,.box code{background:#eceef1;border-radius:5px;padding:1px 6px;font-size:1em}
#lb{position:fixed;inset:0;background:rgba(10,12,15,.92);display:none;align-items:center;justify-content:center;z-index:20;cursor:zoom-out;padding:24px}
#lb.on{display:flex}#lb img{max-width:100%;max-height:100%;background:#fff;border-radius:6px}
@media (max-width:980px){.pair{grid-template-columns:1fr}.pane+.pane{border-left:0;border-top:1px solid var(--line)}.notes div+div{border-left:0;border-top:1px solid var(--line)}.hero h1{font-size:34px}}
"""

JS = r"""
const st={kind:'all',verdict:'all'};
function apply(){document.querySelectorAll('article.card').forEach(c=>{
  const ok=(st.kind==='all'||c.dataset.kind===st.kind)&&(st.verdict==='all'||c.dataset.verdict===st.verdict);
  c.style.display=ok?'':'none';});
  document.querySelectorAll('button.f').forEach(b=>b.setAttribute('aria-pressed',String(st[b.dataset.g]===b.dataset.v)));
  const n=[...document.querySelectorAll('article.card')].filter(c=>c.style.display!=='none').length;
  document.getElementById('shown').textContent=n;}
document.querySelectorAll('button.f').forEach(b=>b.addEventListener('click',()=>{st[b.dataset.g]=b.dataset.v;apply();}));
document.querySelectorAll('.tabs').forEach(t=>t.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{
  const pane=t.closest('.pane');t.querySelectorAll('button').forEach(x=>x.setAttribute('aria-selected',String(x===b)));
  pane.querySelectorAll('figure[data-i]').forEach(f=>f.hidden=f.dataset.i!==b.dataset.i);})));
const lb=document.getElementById('lb'),lbi=lb.querySelector('img');
document.querySelectorAll('figure img').forEach(i=>i.addEventListener('click',()=>{lbi.src=i.src;lbi.alt=i.alt;lb.classList.add('on');}));
lb.addEventListener('click',()=>lb.classList.remove('on'));
document.addEventListener('keydown',e=>{if(e.key==='Escape')lb.classList.remove('on');});
apply();
"""


def ul(items):
    return "<ul>" + "".join(f"<li>{i}</li>" for i in items) + "</ul>"


def card(c):
    off = c.get("official", [])
    if off:
        o_html = "".join(
            f'<figure><img loading="lazy" src="{esc(o["src"])}" alt="{esc(o["alt"])}">'
            f'<figcaption>{o["caption"]}　來源：<a href="{esc(o["url"])}">{esc(o["source"])}</a>，授權 {esc(o["license"])}</figcaption></figure>'
            for o in off)
    else:
        o_html = f'<div class="empty">{c.get("official_none", "這個模組，官方文件沒有對應的圖。")}</div>'
    ours = c.get("ours", [])
    if ours:
        tabs = ""
        if len(ours) > 1:
            tabs = '<div class="tabs" role="tablist">' + "".join(
                f'<button role="tab" data-i="{i}" aria-selected="{str(i == 0).lower()}">{esc(o["label"])}</button>' for i, o in enumerate(ours)) + "</div>"
        figs = "".join(
            f'<figure data-i="{i}"{"" if i == 0 else " hidden"}><img loading="lazy" src="{esc(o["src"])}" alt="{esc(o["alt"])}">'
            f'<figcaption>{o["caption"]}</figcaption></figure>' for i, o in enumerate(ours))
        u_html = tabs + figs
    else:
        u_html = f'<div class="empty">{c.get("ours_none", "工具沒有產生這張圖。")}</div>'
    notes = "".join(f"<div><h5>{t}</h5>{ul(c[k])}</div>" for k, t in (("good", "做得好的地方"), ("gap", "和官方圖的差距"), ("next", "改進方向")) if c.get(k))
    return f'''<article class="card" id="{esc(c["id"])}" data-kind="{c["kind"]}" data-verdict="{c["verdict"]}">
<header><h3>{esc(c["title"])}</h3><span class="tag {c["kind"]}">{KIND[c["kind"]]}</span><span class="tag v-{c["verdict"]}">{VERDICT[c["verdict"]]}</span></header>
<div class="pair"><div class="pane"><h4>官方圖 <small>{esc(c["project"])}</small></h4>{o_html}</div>
<div class="pane"><h4>RTL-To-Graph <small>{esc(c.get("ours_how", "由 RTL 自動產生"))}</small></h4>{u_html}<p class="stats">{c.get("stats", "")}</p></div></div>
<div class="notes">{notes}</div></article>'''


s = data["summary"]
score = "".join(f'<div><b style="color:var(--{k})">{counts.get(k, 0)}</b><span>{VERDICT[k]}</span></div>' for k in ("ours", "tie", "theirs", "none", "fail") if counts.get(k))
fil = '<span class="lab">圖種</span>' + '<button class="f" data-g="kind" data-v="all">全部</button>' + "".join(
    f'<button class="f" data-g="kind" data-v="{k}">{KIND[k]} {kinds[k]}</button>' for k in ("block", "timing", "fsm") if k in kinds)
fil += '<span class="lab">結論</span>' + '<button class="f" data-g="verdict" data-v="all">全部</button>' + "".join(
    f'<button class="f" data-g="verdict" data-v="{k}">{VERDICT[k]} {counts[k]}</button>' for k in ("ours", "tie", "theirs", "none", "fail") if counts.get(k))
boxes = "".join(f'<div class="box {b.get("cls", "")}"><h3>{b["title"]}</h3>{b["html"]}</div>' for b in sorted(s["boxes"], key=lambda b: b.get("order", 0)))
page = f'''<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>RTL-To-Graph 對照圖廊</title><style>{CSS}</style></head><body>
<header class="hero"><div class="wrap"><h1>{s["title"]}</h1><p>{s["lead"]}</p>
<div class="chips">{"".join(f'<span class="chip"><b>{a}</b>{b}</span>' for a, b in s["chips"])}</div></div></header>
<section class="sum"><div class="wrap"><h2>總評</h2><div class="score">{score}</div><div class="cols">{boxes}</div></div></section>
<nav class="filter"><div class="wrap">{fil}<span class="lab">顯示 <b id="shown"></b> 組</span></div></nav>
<main class="wrap">{"".join(card(c) for c in data["cards"])}</main>
<footer><div class="wrap">{s["footer"]}</div></footer>
<div id="lb" role="dialog" aria-label="放大檢視"><img alt=""></div><script>{JS}</script></body></html>'''
io.open(os.path.join(out, "index.html"), "w", encoding="utf-8", newline="\n").write(page)
print("wrote", os.path.join(out, "index.html"), len(page), "cards", len(data["cards"]), counts, kinds)
