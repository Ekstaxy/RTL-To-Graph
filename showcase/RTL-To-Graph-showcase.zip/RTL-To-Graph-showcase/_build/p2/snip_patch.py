"""以片段檔套用修改：python snip_patch.py <repo_root> <snippet_dir> <rel_file>=<name> [...]
每組會讀 <name>_old.txt 與 <name>_new.txt，要求舊片段恰好出現一次。"""
import sys
from pathlib import Path

root, snip = Path(sys.argv[1]), Path(sys.argv[2])
for spec in sys.argv[3:]:
    rel, name = spec.split("=")
    old = (snip / f"{name}_old.txt").read_text(encoding="utf-8").replace("\r\n", "\n")
    new = (snip / f"{name}_new.txt").read_text(encoding="utf-8").replace("\r\n", "\n")
    p = root / rel
    s = p.read_text(encoding="utf-8")
    if s.count(old) != 1:
        raise SystemExit(f"{rel} [{name}]: expected one match, found {s.count(old)}")
    p.write_text(s.replace(old, new), encoding="utf-8")
    print("patched", rel, name)
