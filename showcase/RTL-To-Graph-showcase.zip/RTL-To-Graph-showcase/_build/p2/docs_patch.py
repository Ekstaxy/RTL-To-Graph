"""文件與版本號的修改：python docs_patch.py <repo_root>"""
import sys
from pathlib import Path

root = Path(sys.argv[1])


def patch(rel, pairs):
    p = root / rel
    s = p.read_text(encoding="utf-8")
    for old, new in pairs:
        if s.count(old) != 1:
            raise SystemExit(f"{rel}: expected one match, found {s.count(old)}: {old[:70]}")
        s = s.replace(old, new)
    p.write_text(s, encoding="utf-8")
    print("patched", rel)


L1 = "layers/l1_extract/"

patch(L1 + "src/rtl2d_l1/versions.py", [('SPEC_VERSION = "stage1-spec-v1.7"', 'SPEC_VERSION = "stage1-spec-v1.8"')])

patch(L1 + "docs/SPEC.md", [
    ("| Spec 版本 | `stage1-spec-v1.7`（v1.7 = 前端修正",
     "| Spec 版本 | `stage1-spec-v1.8`（v1.8 = FSM 修正（常數前的註解與空白、與 reset 並列的 soft reset、instance 連線行號所屬的檔案）+ 語意探索的 seed 與 hunt；v1.7 = 前端修正"),
    ("- reset state：reset 條件下（第一層、結構判定或名稱判定、結尾 override）賦的值。",
     "- reset state：reset 條件下（第一層、結構判定或名稱判定、結尾 override）賦的值。條件是「reset 或其他訊號」時（例如 `if (!resetn || softreset)`），該分支賦的值仍是 reset state，其他項另外成為一條從任何 state 出發的轉移（v1.8）。"),
    ("- **狀態探索**：從 reset 值開始做 BFS；每個 state 取樣 300 組（隨機值、設計中的所有常數 ±1、全 1）。",
     "- **狀態探索**：從 reset 值開始做 BFS；每個 state 取樣 300 組（隨機值、設計中的所有常數 ±1、全 1）。v1.8 起另外做兩件事，兩者都只決定取樣什麼，轉移仍然全部來自實際執行：\n"
     "  - **seed**：某個 1-bit 訊號被求值 50 次之後才第一次出現某個值時，記下算出它的那些訊號的值，之後在每個 state 重播（其餘訊號重新取樣）。state 暫存器直接讀取的訊號每個 state 重播 16 次，其餘 3 次，最多保留 48 組。\n"
     "  - **hunt**：state 暫存器直接讀取的 1-bit 訊號如果始終只出現一種值，單獨對它求值最多 6000 次（比執行一個 cycle 便宜得多），其中一半從既有的 seed 出發。每次分析最多 hunt 8 個訊號。"),
    ("- **驗證**：亂改等價 benchmark 18/18 同構（語法抽取 0/18）；一般 RTL 37/37 consistent。",
     "- **驗證**：亂改等價 benchmark 18/18 同構（語法抽取 0/18）；一般 RTL 37/37 consistent。v1.8 的 seed 與 hunt：picosoc `spimemio.state` 的 13 個 state 全部到達（先前只到 3 個，因為每個 state 都要等子模組的 `din_ready`，隨機取樣出現的機率約 0.1%）；亂改 benchmark 仍是 18/18；5 個資料集的交叉驗證結果不變。"),
])

patch(L1 + "src/rtl2d_l1/frontend/fsm_semantic.py", [
    ("""    samples (random + every literal constant of the design +/-1) give the next-state values.
""",
     """    samples (random + every literal constant of the design +/-1) give the next-state values;
  * guards that uniform sampling rarely satisfies are found by keeping the signal values behind
    every one-bit value that shows up late (seeds, replayed in each state) and by evaluating a
    stuck guard of the state register on its own (hunts). See analyze().
"""),
])

patch(L1 + "docs/CHANGELOG.md", [
    ("""## Unreleased (2026-11-16)
Bug fixes only; SPEC and `SPEC_VERSION` unchanged.
""",
     """## stage1-spec-v1.8 (2026-11-17)
FSM fixes and a more thorough state exploration. Output schemas are unchanged.
- `fsm.py` reset state: `if (!resetn || softreset) state <= A;` now gives reset state A. The branch
  was not seen as a reset because its condition also reads a non-reset signal, so the FSM had no
  reset state and the hybrid check called it a mismatch. The other terms of the condition become
  a transition `* -> A`, and only they guard the else branch.
- `fsm_semantic.analyze` finds guards that uniform sampling rarely satisfies (SPEC 6c: seeds and
  hunts). picosoc `spimemio.state` waits for `din_ready` from a submodule in ten of its states, a
  value about 0.1% of random samples produce: 13 of 13 states are reached now (3 before) and the
  check says consistent. e3 rewrite benchmark still 18/18; the cross-check over examples, RTLLM,
  VerilogEval, picorv32 and opensource is unchanged (46 consistent, 4 consistent-subset, 2 mismatch
  (both picorv32_wb, as before), 1 semantic-only) and takes 21% longer.
"""),
])

patch("pipeline/experiments/x4_fsm_timing/README.md", [
    ("""## Conclusion
""",
     """### 2026-11-17: file order no longer matters to iverilog
`sim.py` now runs iverilog with `-u` (one compilation unit per file). slang, which L1 uses, reads
every file as its own unit, so macros do not leak from one file to the next; iverilog kept them in
command-line order, and `picosoc.v` stops with `` `error `` when `picorv32.v` was read first. A
design L1 elaborates therefore failed to compile, and without Verilator installed the run ended
in `sim: verilator not found`. With `-u` picosoc simulates under iverilog.

## Conclusion
"""),
])
