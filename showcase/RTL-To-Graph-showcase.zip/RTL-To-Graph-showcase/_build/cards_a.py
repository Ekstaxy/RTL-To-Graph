# 架構圖與時序圖的對照卡片（評語依實際輸出撰寫）
import json, os

S = os.environ["GAL_S"]


def blk(tag, engines, alt, note=""):
    """我們的架構圖：依引擎列出分頁，圖說帶實測數字。"""
    b = json.load(open(os.path.join(S, "blk", tag, "block.json"), encoding="utf-8"))
    names = {"busbar": "匯流排長條", "dot": "分層 dot", "hola": "HOLA", "grid": "格狀", "system": "系統圖畫法"}
    out = []
    for e in engines:
        if e == "system":
            out.append({"label": names[e], "src": f"blk/{tag}/x1.system.svg", "alt": alt + "，系統圖畫法",
                        "caption": "專案內建的系統圖畫法，黑白線條，匯流排用粗線。" + note})
            continue
        m = b["engines"][e]
        out.append({"label": names[e], "src": f"blk/{tag}/e3.{e}.svg", "alt": alt + "，" + names[e] + "排版",
                    "caption": f"{b['bridge']['units']} 個單元，{m['cross']} 個交叉，反查錯誤 {m['roundtrip']} 個，排版 {m['seconds']} 秒。" + note})
    return out


def off(proj, file, alt, caption, repo, path, lic, src=None):
    return {"src": src or f"official/{proj}/{file}", "alt": alt, "caption": caption,
            "url": f"https://github.com/{repo}/blob/HEAD/{path}", "source": f"{repo} · {path}", "license": lic}


TEACH = "L1 用既有的 teacher 標註，其餘全自動"
cards = []

cards.append({
    "id": "picosoc", "kind": "block", "verdict": "tie", "project": "YosysHQ/picorv32", "title": "PicoSoC 頂層",
    "official": [off("", "", "PicoSoC 官方總覽圖：XIP SPI Flash Controller、UART、SRAM、PicoRV32 掛在 32 位元系統匯流排上，右側是使用者自己的電路", "官方手繪的總覽圖。", "YosysHQ/picorv32", "picosoc/overview.svg", "ISC", src="offsvg/picosoc_overview.svg")],
    "ours": blk("picorv32_picosoc", ["busbar", "grid", "dot", "hola", "system"], "RTL-To-Graph 產生的 PicoSoC 架構圖"),
    "ours_how": TEACH,
    "good": ["四個功能單元和官方圖一一對上：CPU、SPI flash controller、UART、On-chip RAM。", "多畫出了官方圖省略的「Address decode and read mux」，這是 RTL 裡真實存在的位址解碼。", "外部腳位自動歸成 flash_spi、uart、iomem、irq 四組介面，不是一根一根列。"],
    "gap": ["官方圖把匯流排標成「32 Bit System Bus」，我們的匯流排沒有名稱也沒有位寬。", "官方圖標出 SRAM 預設 1 kB、CPU 的指令集，這些參數資訊我們沒有帶出來。", "官方圖畫出「Your Circuit」的使用情境，這是設計者的意圖，RTL 裡沒有。"],
    "next": ["連線標上介面名稱與位寬。", "把關鍵參數放進方塊副標，例如記憶體大小。"],
})

cards.append({
    "id": "darksocv", "kind": "block", "verdict": "tie", "project": "darklife/darkriscv", "title": "DarkSoCV 頂層",
    "official": [off("darklife_darkriscv", "darksocv.png", "DarkSoCV 官方架構圖：DarkRISCV、DarkBridge、DarkRAM、DarkIO、SDRAM Controller，以 I-BUS、D-BUS、X-BUS 相連", "官方架構圖，同時畫出同步 Harvard 與非同步 von Neumann 兩種組態。", "darklife/darkriscv", "doc/darksocv.png", "BSD-3-Clause")],
    "ours": blk("dark_darksocv", ["busbar", "dot", "hola", "grid", "system"], "RTL-To-Graph 產生的 DarkSoCV 架構圖"),
    "ours_how": TEACH,
    "good": ["版面和官方圖同一個骨架：中央一條匯流排，RAM 與 I/O 掛在上面。", "畫的是這份 RTL 實際展開後的組態，所以沒有出現未啟用的 SDRAM 與快取。", "多畫了官方圖省略的 Clock/reset 與「Unmapped region responders」。"],
    "gap": ["官方圖把 DarkRISCV 核心單獨畫成一塊；RTL 裡它包在 DarkBridge 內部，我們只畫出一個「CPU bridge」，看不到處理器本體。", "官方圖替三條匯流排命名，並用雙向粗箭頭表示；我們的線沒有名稱。", "官方圖一張同時說明兩種組態，我們一次只能畫一種。"],
    "next": ["允許把重要的下一層模組提升到本層顯示。", "匯流排命名與雙向箭頭。", "以參數組態為單位出多張圖，或用虛線框表示選配模組。"],
})

cards.append({
    "id": "serv_rf_top", "kind": "block", "verdict": "tie", "project": "olofk/serv", "title": "SERV 含暫存器檔的頂層 serv_rf_top",
    "official": [off("olofk_serv", "serv_rf_top.png", "SERV 官方圖：serv_top、serv_rf_ram_if、serv_rf_ram 三個方塊，外部有 Extension interface、Instruction bus、Data bus、Clock、Reset、Timer IRQ", "官方介面圖。", "olofk/serv", "doc/serv_rf_top.png", "ISC")],
    "ours": blk("serv_serv_rf_top", ["busbar", "hola", "dot", "system"], "RTL-To-Graph 產生的 serv_rf_top 架構圖"),
    "ours_how": TEACH,
    "good": ["三個方塊完全對上，而且用的是功能名稱：SERV core、Register-file RAM interface、Register-file RAM。", "外部介面同樣歸成 ibus、dbus、extension、irq 四組。", "方塊依類別上色，一眼分得出處理器、介面與記憶體。"],
    "gap": ["官方圖把三塊排成一條直線，讀起來就是資料的流向；我們排成兩列，核心反而在右上角。", "官方圖的介面箭頭貼著所屬方塊，我們把所有介面集中在左側，拉出長線繞一圈。"],
    "next": ["只被一個方塊使用的外部介面，直接畫在該方塊旁邊。", "三個以下的單元優先排成一列。"],
})

cards.append({
    "id": "serv_alu", "kind": "block", "verdict": "tie", "project": "olofk/serv", "title": "SERV 的算術邏輯單元 serv_alu",
    "official": [off("olofk_serv", "serv_alu_int.png", "SERV 官方的 serv_alu 內部電路圖：加減法器、比較、布林運算與結果多工器，畫到邏輯閘層級", "官方內部電路圖，畫到邏輯閘。", "olofk/serv", "doc/serv_alu_int.png", "ISC")],
    "ours": blk("serv_serv_alu", ["dot", "busbar", "system"], "RTL-To-Graph 產生的 serv_alu 架構圖"),
    "ours_how": TEACH,
    "good": ["自動歸納出的三塊：Serial adder、Comparator、Boolean unit，正好對應官方圖的三個區域。", "外部訊號歸成 state、control、serial data 三組。"],
    "gap": ["這是位元序列處理器，重點在進位暫存器與一位元加法怎麼接，官方圖畫得出來，我們的方塊層級看不到。", "標註裡其實還有第四組「Result mux」，圖上被併掉了。", "官方圖標出每條內部訊號的名稱，例如 result_add、add_cy。"],
    "next": ["葉節點模組提供更細一層的畫法：暫存器、多工器與運算子各自成符號。", "重要的內部訊號在線上標名。"],
})

cards.append({
    "id": "darkriscv", "kind": "block", "verdict": "theirs", "project": "darklife/darkriscv", "title": "DarkRISCV 處理器核心",
    "official": [off("darklife_darkriscv", "darkriscv.png", "DarkRISCV 官方資料路徑圖：PC、指令快取、解碼、暫存器堆、三個 ALU、分支邏輯與資料快取", "官方資料路徑圖。", "darklife/darkriscv", "doc/darkriscv.png", "BSD-3-Clause")],
    "ours": blk("dark_darkriscv", ["hola", "dot", "busbar", "system"], "RTL-To-Graph 產生的 DarkRISCV 核心架構圖", " 格狀引擎在這個輸入上失敗。"),
    "ours_how": TEACH,
    "good": ["七個功能單元的命名合理：Instruction fetch、Decode、Register file、Execute、Load/store unit、Pipeline control、CSR and traps。", "所有連線都通過反查，沒有接錯。"],
    "gap": ["官方圖看得出指令怎麼流：PC 到指令、解碼、暫存器、ALU、再回寫。我們的圖只有方塊和繞來繞去的線，看不出先後。", "最少也有 22 個交叉，長線繞整張圖一圈。", "官方圖用梯形 ALU、暫存器堆疊等符號，我們全部是矩形。"],
    "next": ["單一大模組的處理器改用資料路徑畫法：依管線階段分欄，由左到右。", "這需要繞線器支援由上下進出的埠，是專案紀錄裡排第一的工程項目。"],
})

cards.append({
    "id": "serv_top", "kind": "block", "verdict": "theirs", "project": "olofk/serv", "title": "SERV 核心 serv_top",
    "official": [off("olofk_serv", "serv_dataflow.png", "SERV 官方資料流圖：serv_immdec、serv_ctrl、serv_csr、serv_bufreg、serv_alu、serv_bufreg2、serv_mem_if、serv_rf_if 之間的資料連線", "官方資料流圖，只畫資料路徑。", "olofk/serv", "doc/serv_dataflow.png", "ISC")],
    "ours": blk("serv_serv_top", ["dot", "hola", "busbar", "system"], "RTL-To-Graph 產生的 serv_top 架構圖"),
    "ours_how": TEACH,
    "good": ["十一個單元全部畫出，連線反查零錯誤。", "自動把 Bufreg、Bufreg2、ALU 圈成一個「serial_datapath」群組，和官方圖的中央區塊一致。"],
    "gap": ["最少 82 個交叉，實際上無法閱讀。", "官方圖只挑資料路徑，控制訊號一律不畫；我們把 114 條連線全畫了。", "官方圖在每個方塊上列出相關的埠名，連線因此不需要標籤。"],
    "next": ["提供「只看資料」的檢視：依 L1 已有的重要度分數，濾掉控制與低分連線。", "方塊內顯示埠名。", "專案紀錄已指出這個設計該用資料路徑畫法，而不是系統圖畫法。"],
})

cards.append({
    "id": "biriscv", "kind": "block", "verdict": "theirs", "project": "ultraembedded/biriscv", "title": "biRISC-V 處理器核心",
    "official": [off("ultraembedded_biriscv", "biRISC-V.png", "biRISC-V 官方管線圖：PC、Fetch、Pre-decode、Issue、ALU、Mem、Writeback 七個階段，各階段內有對應單元", "官方管線圖，依階段分欄。", "ultraembedded/biriscv", "docs/biRISC-V.png", "Apache-2.0")],
    "ours": blk("biriscv_riscv_core", ["dot", "busbar", "hola", "system"], "RTL-To-Graph 產生的 biRISC-V 核心架構圖"),
    "ours_how": "頂層沒有現成標註，只用規則式標註",
    "good": ["九個子模組都畫出來：Frontend、Issue、Exec0、Exec1、LSU、MUL、DIV、CSR、MMU。", "Exec0 與 Exec1 兩個並列，對應官方圖的雙 ALU，這是雙發射的關鍵特徵。", "只有 1 到 7 個交叉，連線乾淨。"],
    "gap": ["官方圖依管線階段由左到右排，我們的排法沒有階段順序。", "沒有標註時，外框只能叫「submodules」，沒有資訊量。", "官方圖畫出 Frontend 內部的分支預測器與外部的快取，我們停在第一層。"],
    "next": ["偵測到管線暫存器時，自動依階段分欄。", "規則式標註至少用頂層模組名當外框名稱。", "把深度旋鈕接進這條流程，可以一張圖展開兩層。"],
})

cards.append({
    "id": "axixbar", "kind": "block", "verdict": "theirs", "project": "ZipCPU/wb2axip", "title": "AXI 交叉開關 axixbar",
    "official": [off("ZipCPU_wb2axip", "axixbar.png", "wb2axip 官方的 axixbar 概念圖：四個 AXI Master 各接兩個 Skid buffer，經 Crossbar Interconnect 連到八個 AXI Slave", "官方概念圖。", "ZipCPU/wb2axip", "doc/axixbar.png", "Apache-2.0")],
    "ours": blk("wb2axip_axixbar", ["dot", "grid", "busbar", "system"], "RTL-To-Graph 產生的 axixbar 架構圖"),
    "ours_how": TEACH,
    "good": ["內部真正的結構有畫出來：讀寫各自的位址解碼、仲裁器、回應路徑與計數器。", "187 條連線全部通過反查。"],
    "gap": ["官方圖講的是這個模組的用途：誰接誰。我們畫的是它的內部實作，最少 66 個交叉，讀不出重點。", "主從埠是參數化的陣列，官方圖畫成一排相同的方塊；我們沒有把陣列攤開成這種對稱的樣子。", "十組 AXI 通道介面全擠在左側。"],
    "next": ["參數化的埠陣列，畫成一排重複的端點。", "提供「外部視角」的畫法：只畫本模組與它連接的對象。", "AXI 的五個通道合併成一個介面。"],
})

for tag, title, proj, alt, eng, good, gap in [
    ("picorv32_spimemio", "PicoSoC 的 SPI Flash 控制器 spimemio", "YosysHQ/picorv32", "RTL-To-Graph 產生的 spimemio 架構圖", ["busbar", "hola", "dot", "system"],
     ["五個單元的命名直接說明功能：Read sequencer FSM、Xfer engine interface、Memory bus and word assembly、Config register、Flash pin mux。", "只有 1 個交叉。"],
     ["沒有官方圖可比。Flash pin mux 只有一條線連出去，看起來像沒接完，其實是連線被合併了。"]),
    ("wb2axip_axidma", "AXI DMA 控制器 axidma", "ZipCPU/wb2axip", "RTL-To-Graph 產生的 axidma 架構圖", ["hola", "busbar", "dot", "system"],
     ["讀引擎、寫引擎、對齊 FIFO、DMA 控制器、暫存器介面都分出來了，命名可讀。", "AXI-lite 暫存器介面自動圈成一個群組，內含三個 skid buffer。"],
     ["最少 40 個交叉，控制虛線繞全圖一圈。官方只提供時序圖，沒有架構圖。"]),
    ("wb2axip_axivfifo", "AXI 虛擬 FIFO axivfifo", "ZipCPU/wb2axip", "RTL-To-Graph 產生的 axivfifo 架構圖", ["dot", "busbar", "hola", "system"],
     ["資料流向看得出來：input_fifo、write_burst_engine、read_burst_engine、output_fifo。"],
     ["單元名稱沿用訊號風格的底線小寫，不像其他圖用自然語言。最少 25 個交叉。官方只提供時序圖。"]),
]:
    cards.append({"id": tag.split("_", 1)[1], "kind": "block", "verdict": "none", "project": proj, "title": title,
                  "official": [], "official_none": "官方文件沒有這個模組的架構圖。",
                  "ours": blk(tag, eng, alt), "ours_how": TEACH, "good": good, "gap": gap,
                  "next": ["沒有官方圖的模組最需要自動產生的圖，優先把這類中型模組的交叉數壓下來。"]})

# ───────── 時序圖 ─────────
def tm(src, alt, cap):
    return {"label": cap.split("｜")[0], "src": src, "alt": alt, "caption": cap}

W = "ZipCPU/wb2axip"
PATCH = "多檔設計原本會當掉，補一行越界檢查後才出圖"

cards.append({
    "id": "t_axidouble", "kind": "timing", "verdict": "theirs", "project": W, "title": "axidouble 的讀取交易",
    "official": [off("", "", "wb2axip 官方 axidouble 讀取時序圖：三筆 AR 請求、對應的 R 資料節拍與 RLAST，資料以 A0、D0 等符號標示並依交易上色", "官方時序圖，一張圖講完三筆讀取交易。", W, "doc/gfx/axidouble-read.svg", "Apache-2.0", src="offsvg/wb2axip_axidouble-read.svg")],
    "ours": [tm("x4p/wb2axip_axidouble.s_axi_ar.first-fire.svg", "RTL-To-Graph 產生的 axidouble AR 通道時序圖", "AR 通道｜讀位址交握，箭頭指到內部的 araddr 暫存器。"),
             tm("x4p/wb2axip_axidouble.s_axi_r.back-to-back.svg", "RTL-To-Graph 產生的 axidouble R 通道時序圖", "R 通道｜連續兩拍資料與 RLAST。")],
    "ours_how": PATCH,
    "stats": "這個模組共產生 20 張時序圖，五項檢查全數通過。",
    "good": ["每個通道各自一張，交握關係清楚。", "因果箭頭是官方圖沒有的：ARVALID 與 ARREADY 成立後，下一拍 araddr 才更新。", "自動帶出相關的內部暫存器。"],
    "gap": ["官方圖把 AR 和 R 放在同一張，看得出一筆請求對應哪幾拍資料；我們拆成兩張，對不起來。", "官方圖用 A0、D0 這種符號並依交易上色，我們顯示隨機刺激產生的原始數值，例如 347535eb。", "ARSIZE、ARBURST、ARPROT 這些和重點無關的訊號佔掉一半的版面。"],
    "next": ["跨通道的交易視窗：同一筆交易的請求與回應畫在同一張。", "資料改用符號標籤，同一筆交易同色。", "和交握無關的旁支訊號預設收合。"],
})

cards.append({
    "id": "t_axi2axil", "kind": "timing", "verdict": "theirs", "project": W, "title": "axi2axilite 的突發讀取",
    "official": [off("", "", "wb2axip 官方 axi2axilite 突發讀取時序圖：三筆 AXI 突發被拆成十二筆 AXI-Lite 讀取，再組回 AXI 的 R 通道", "官方時序圖，上游 AXI 與下游 AXI-Lite 畫在一起。", W, "doc/gfx/axi2axil-read-burst.svg", "Apache-2.0", src="offsvg/wb2axip_axi2axil-read-burst.svg")],
    "ours": [tm("x4p/wb2axip_axi2axilite.s_axi_ar.first-fire.svg", "RTL-To-Graph 產生的 axi2axilite 上游 AR 通道時序圖", "上游 AR｜AXI 端的讀位址。"),
             tm("x4p/wb2axip_axi2axilite.m_axi_r.first-fire.svg", "RTL-To-Graph 產生的 axi2axilite 下游 R 通道時序圖", "下游 R｜AXI-Lite 端的讀資料。")],
    "ours_how": PATCH,
    "stats": "這個模組共產生 10 張時序圖，五項檢查全數通過。",
    "good": ["上下游各通道都有出圖。", "下游圖自動帶出上游的 s_axi_rvalid，知道兩端有關聯。"],
    "gap": ["這個模組的價值就是「一筆突發拆成多筆」，官方圖一眼看得出來；我們的圖完全看不到這件事。", "隨機刺激沒有產生一筆完整的突發，ARLEN 每拍都在變。", "視窗只有五六個週期，轉換還沒發生就結束了。"],
    "next": ["橋接類模組要有「一進一出」的端到端視窗。", "刺激改用形式工具找出的最短見證波形，保證交易完整。這是專案計畫裡尚未完成的項目。"],
})

cards.append({
    "id": "t_aximrd2wbsp", "kind": "timing", "verdict": "theirs", "project": W, "title": "aximrd2wbsp：AXI 讀取轉 Wishbone",
    "official": [off("ZipCPU_wb2axip", "aximrd2wbsp.png", "wb2axip 官方 aximrd2wbsp 時序圖：AR 請求、Wishbone 的 cyc、stb、addr、ack、data，以及回到 AXI 的 R 通道", "官方時序圖，請求、Wishbone 匯流排、回應三段都在。", W, "doc/gfx/aximrd2wbsp.png", "Apache-2.0")],
    "ours": [tm("x4flat/wb2axip_aximrd2wbsp.s_axi_ar.first-fire.svg", "RTL-To-Graph 產生的 aximrd2wbsp AR 通道時序圖", "AR 通道｜只有上游的讀位址通道。")],
    "ours_how": "未修改，直接出圖",
    "stats": "只產生 2 張，都是 AR 通道。",
    "good": ["AR 通道的訊號選得完整。"],
    "gap": ["只認出 AR 一個介面，Wishbone 端和 R 通道完全沒畫。官方圖的三段裡我們只有第一段。", "視窗內沒有任何因果箭頭。", "axi_id 整條是未知值，測試平台沒有驅動到。"],
    "next": ["介面樣板要認得 Wishbone 主端的 cyc、stb、ack 組合。", "自動產生的測試平台需要替下游接上會回應的模型，否則交易永遠走不完。"],
})

cards.append({
    "id": "t_axil2apb", "kind": "timing", "verdict": "theirs", "project": W, "title": "axil2apb：AXI-Lite 轉 APB",
    "official": [off("ZipCPU_wb2axip", "axil2apb-reads.png", "wb2axip 官方 axil2apb 讀取波形：AXI 讀位址與讀資料通道，以及 APB 的 PSEL、PENABLE、PREADY", "官方波形截圖，取自模擬器。", W, "doc/gfx/axil2apb-reads.png", "Apache-2.0")],
    "ours": [tm("x4flat/wb2axip_axil2apb.s_axi_ar.first-fire.svg", "RTL-To-Graph 產生的 axil2apb AR 通道時序圖", "AR 通道｜讀位址交握。"),
             tm("x4flat/wb2axip_axil2apb.s_axi_w.first-fire.svg", "RTL-To-Graph 產生的 axil2apb W 通道時序圖", "W 通道｜寫資料交握。")],
    "ours_how": "未修改，直接出圖",
    "stats": "共 4 張，五項檢查全數通過。",
    "good": ["版面比模擬器截圖乾淨得多，白底、訊號名對齊、數值可讀。", "有因果箭頭。"],
    "gap": ["APB 那一側的 PSEL、PENABLE、PREADY 完全沒出現，只帶到一條 M_APB_PRDATA。", "官方截圖雖然醜，但看得到一筆讀取從 AXI 進、APB 出、再回 AXI 的全程。"],
    "next": ["加入 APB 的介面樣板。", "排版已經贏過模擬器截圖，補上端到端視窗後這一類可以直接取代官方圖。"],
})

cards.append({
    "id": "t_wbxclk", "kind": "timing", "verdict": "theirs", "project": W, "title": "wbxclk：Wishbone 跨時脈域",
    "official": [off("", "", "wb2axip 官方 wbxclk 時序圖：上游 Wishbone 請求、跨時脈後的下游請求與回應，兩個時脈域", "官方時序圖，兩個時脈域的請求與回應都走完。", W, "doc/gfx/wbxclk.svg", "Apache-2.0", src="offsvg/wb2axip_wbxclk.svg")],
    "ours": [tm("x4flat/wb2axip_wbxclk.fifo.first-fire.svg", "RTL-To-Graph 產生的 wbxclk 雙時脈域時序圖", "雙時脈域｜兩個時脈域各自成組，週期 10 ns 與 14 ns。"),
             tm("x4flat/wb2axip_wbxclk.i_wb.first-fire.svg", "RTL-To-Graph 產生的 wbxclk 上游 Wishbone 時序圖", "上游 Wishbone｜stb 拉起後，視窗內沒有等到 ack。")],
    "ours_how": "未修改，直接出圖",
    "stats": "共 3 張。",
    "good": ["自動認出兩個時脈域並分組，各自標出週期。", "未初始化的訊號用斜線表示。"],
    "gap": ["上游請求送出後，視窗結束前都沒有等到回應，交易沒有走完。", "下游的 o_xclk_cyc、stb 沒有動作，看不出請求有跨過去。", "沒有任何跨時脈域的箭頭，這正是這個模組的重點。"],
    "next": ["跨時脈域的交易需要更長的視窗，並壓縮中間的等待。壓縮機制專案已經有，要讓它在這裡觸發。", "下游要有會回 ack 的模型。"],
})

cards.append({
    "id": "t_axis2mm", "kind": "timing", "verdict": "theirs", "project": W, "title": "axis2mm：串流寫入記憶體",
    "official": [off("", "", "wb2axip 官方 axis2mm 時序圖：命令啟動、FIFO 水位、AXI 寫位址與寫資料突發、完成中斷", "官方時序圖，從命令啟動到完成中斷。", W, "doc/axis2mm_sb.svg", "Apache-2.0", src="offsvg/wb2axip_axis2mm_sb.svg")],
    "ours": [tm("x4p/wb2axip_axis2mm.s_axis_t.back-to-back.svg", "RTL-To-Graph 產生的 axis2mm 串流輸入時序圖", "串流輸入｜TVALID、TREADY、TDATA、TLAST。")],
    "ours_how": PATCH,
    "stats": "這個模組共產生 19 張時序圖。",
    "good": ["串流介面的訊號完整，含 TLAST 與 TUSER。"],
    "gap": ["官方圖講的是一次完整的搬移：下命令、FIFO 填到門檻、發出寫突發、收到回應、拉中斷。我們只有介面交握，看不到這個流程。", "官方圖把 fifo_fill 這種內部狀態當主角，我們帶出的內部訊號是 phantom_start，對讀者沒有意義。"],
    "next": ["控制暫存器驅動的模組，需要「下命令到完成」的情境樣板。", "內部訊號的挑選應該用 L1 的重要度，而不是只看連線距離。"],
})

for cid, title, osrc, opath, oalt, ocap, ours, stats, good, gap in [
    ("t_axidma", "axidma：記憶體搬移", "offsvg/wb2axip_axidma.svg", "doc/gfx/axidma.svg", "wb2axip 官方 axidma 時序圖：AXI-Lite 寫入長度、來源、目的與啟動，接著讀突發、寫突發、FIFO 水位與完成中斷", "官方時序圖，一次完整的 DMA 搬移。",
     [tm("x4p/wb2axip_axidma.s_axil_aw.first-fire.svg", "RTL-To-Graph 產生的 axidma 控制介面寫位址時序圖", "控制介面｜AXI-Lite 寫位址交握。")], "這個模組共產生 17 張時序圖。",
     ["控制介面的五個通道都有出圖。"], ["同上一組：官方圖是一個完整情境，我們是十七張互不相干的通道交握。", "真正的資料通道 m_axi 只認出 B 通道。"]),
    ("t_axivfifo", "axivfifo：虛擬 FIFO", "offsvg/wb2axip_axivfifo.svg", "doc/gfx/axivfifo.svg", "wb2axip 官方 axivfifo 時序圖：輸入串流、輸入 FIFO 水位、AXI 寫突發、AXI 讀突發、輸出 FIFO 與輸出串流", "官方時序圖，資料從進到出的全程。",
     [tm("x4p/wb2axip_axivfifo.m_axi_ar.first-fire.svg", "RTL-To-Graph 產生的 axivfifo 讀位址通道時序圖", "讀位址｜帶出 mem_data_available_w 等內部狀態。"), tm("x4p/wb2axip_axivfifo.s_axis_t.first-fire.svg", "RTL-To-Graph 產生的 axivfifo 輸入串流時序圖", "輸入串流｜TVALID、TREADY 與資料。")], "這個模組共產生 13 張時序圖。",
     ["這一組帶出的內部訊號有意義：mem_data_available_w、vfifo_full。", "讀位址每次遞增 400，看得出突發長度。"], ["官方圖把寫入與讀出放在同一條時間軸上，看得出資料在記憶體裡停了多久。", "我們的視窗太短，看不到資料繞一圈。"]),
]:
    cards.append({"id": cid, "kind": "timing", "verdict": "theirs", "project": W, "title": title,
                  "official": [off("", "", oalt, ocap, W, opath, "Apache-2.0", src=osrc)], "ours": ours, "ours_how": PATCH, "stats": stats,
                  "good": good, "gap": gap, "next": ["情境層級的視窗，橫跨多個介面。"]})

cards.append({
    "id": "t_apbxclk", "kind": "timing", "verdict": "fail", "project": W, "title": "apbxclk：APB 跨時脈域",
    "official": [off("ZipCPU_wb2axip", "apbxclk.png", "wb2axip 官方 apbxclk 波形：上游與下游 APB 的 PSEL、PENABLE、PREADY 與資料", "官方波形截圖。", W, "doc/gfx/apbxclk.png", "Apache-2.0")],
    "ours": [], "ours_none": "沒有產生任何時序圖。工具沒有回報錯誤，只是沒認出任何介面。",
    "ours_how": "未修改",
    "good": ["沒有硬畫，也沒有當掉。"],
    "gap": ["APB 是很常見的匯流排，目前的介面樣板不認得。"],
    "next": ["補上 APB 樣板：PSEL、PENABLE、PREADY 三個訊號的組合。"],
})

OLD = "old/"
cards.append({
    "id": "t_skid", "kind": "timing", "verdict": "none", "project": W, "title": "skidbuffer：暫存緩衝",
    "official": [], "official_none": "repo 裡沒有這個模組的時序圖。作者在部落格另有說明文章。",
    "ours": [tm("x4flat/wb2axip_skidbuffer.i.first-stall.svg", "RTL-To-Graph 產生的 skidbuffer 輸入端受阻時序圖", "輸入端受阻｜下游不收時，資料暫存進緩衝。"),
             tm("x4flat/wb2axip_skidbuffer.o.back-to-back.svg", "RTL-To-Graph 產生的 skidbuffer 輸出端連續傳輸時序圖", "輸出端連續｜連續傳輸不掉拍。")],
    "ours_how": "未修改，直接出圖",
    "stats": "共 6 張，正好是兩個介面各三種情境。",
    "good": ["這種單一功能、兩個介面的模組，是目前時序圖做得最好的一類。", "三種情境：首次成交、首次受阻、連續傳輸，剛好就是這個模組要說明的行為。", "箭頭顯示資料何時進到暫存。"],
    "gap": ["輸入端與輸出端分成兩張，受阻時資料怎麼從一端傳到另一端要自己對。"],
    "next": ["兩個介面同時脈時，提供合併成一張的選項。"],
})

cards.append({
    "id": "t_afifo", "kind": "timing", "verdict": "none", "project": W, "title": "afifo：非同步 FIFO",
    "official": [], "official_none": "官方文件沒有這個模組的時序圖。",
    "ours": [tm(OLD + "afifo.fifo.first-fire.svg", "RTL-To-Graph 產生的 afifo 雙時脈域時序圖", "首次寫入到讀出｜寫入端 10 ns、讀取端 14 ns，橘色虛線是跨時脈域。")],
    "ours_how": "未修改，直接出圖",
    "stats": "五項檢查全數通過，9 條箭頭全部對得上 RTL 路徑。",
    "good": ["兩個時脈域分組，各有自己的時脈與週期。", "橘色虛線標出格雷碼指標跨域的路徑，這是手繪圖最難畫對的部分。", "資料從寫入到讀出走完一圈。"],
    "gap": ["箭頭在中段交疊，要放大才分得清。"],
    "next": ["跨域箭頭錯開起點，或只保留每對訊號的第一條。"],
})
