# 從 L1 corpus manifests 挑出要比較的設計，寫成 x4 的 manifest
import json, glob, sys, os
root = os.path.expanduser("~/rtl2d-demo/repo")
want = sys.argv[2].split(",")
ents = {}
for f in sorted(glob.glob(f"{root}/layers/l1_extract/data/corpus/*.json")):
    try: m = json.load(open(f))
    except Exception: continue
    items = m if isinstance(m, list) else m.get("designs", m.get("entries", []))
    for e in items:
        if isinstance(e, dict) and "name" in e: ents[e["name"]] = e
out, missing = [], []
for n in want:
    e = ents.get(n)
    if not e: missing.append(n); continue
    fix = lambda p: "layers/l1_extract/data/rtl/" + p
    files = [fix(p) for p in e["files"]]
    ok = all(os.path.exists(f"{root}/{p}") for p in files)
    out.append({"name": n, "files": files, "top": e.get("top"), "include_dirs": [fix(p) for p in e.get("include_dirs", [])], "defines": e.get("defines", []), "tb": None})
    print(f"{n:34s} top={e.get('top')} files={len(files)} exist={ok}")
json.dump(out, open(sys.argv[1], "w"), indent=1)
print("missing:", missing, "| total corpus entries:", len(ents))
