"""三種圖合一的完整成果頁：python make_all.py <scratch_dir> <gallery_dir>
讀 all/x4/index.json（狀態機與時序圖）、all/blk/*/block.json（架構圖），輸出 <gallery_dir>/all.html 與 full/ 下的圖檔。"""
import html, io, json, os, shutil, sys

S, OUT = sys.argv[1], sys.argv[2]
esc = html.escape
idx = json.load(io.open(os.path.join(S, "all/x4/index.json"), encoding="utf-8"))
best = json.load(open(os.path.join(S, "all/best.json")))

# 專案、顯示名稱，以及逐一看圖後寫的評語：b 架構圖、f 狀態機、t 時序圖
#   fg: good 正確 / counter 計數器攤開 / false 誤判 / miss 漏抓 / none 沒有狀態機
#   tg: full 情境完整 / part 只有片段 / empty 沒有輸出
W, P, D, B, V = "ZipCPU/wb2axip", "YosysHQ/picorv32", "darklife/darkriscv", "ultraembedded/biriscv", "olofk/serv"
EVAL = {
 "wb2axip_axidouble": (W, "axidouble", "11 個單元，連線拉得很長。", "none", "沒有狀態機，也沒有誤報。", "part", "20 張都是單一通道的交握，看不出一筆請求對應哪幾拍回應。"),
 "wb2axip_axi2axilite": (W, "axi2axilite", "自動分成寫入拆分、寫回應合併、讀取拆分、讀回傳四個群組，結構清楚；方塊偏小。", "none", "沒有狀態機，也沒有誤報。", "part", "10 張單通道片段，看不出一筆突發被拆成多筆。"),
 "wb2axip_axis2mm": (W, "axis2mm", "12 個單元，暫存器介面與串流 FIFO 各成一群。", "false", "phantom_start 是一位元旗標，被誤認成狀態機。", "part", "19 張介面交握，沒有從下命令到完成的流程。"),
 "wb2axip_axidma": (W, "axidma", "單元命名可讀，但控制線繞全圖一圈。", "false", "phantom_write 被誤認成狀態機；phantom_read 被檢查正確擋下。", "part", "17 張通道交握，沒有一次完整的搬移。"),
 "wb2axip_axivfifo": (W, "axivfifo", "資料流向看得出來；單元名沿用底線小寫。", "false", "兩個 phantom 旗標都被誤認成狀態機。", "part", "14 張；帶出的內部訊號有意義，但視窗太短，看不到資料繞一圈。"),
 "wb2axip_wbxclk": (W, "wbxclk", "四個單元：上游請求接收、下游主端、回傳路徑、未回應計數，一看就懂。", "none", "沒有狀態機。err_state 是一位元旗標，這次沒有誤報。", "part", "兩個時脈域有分組，但請求送出後沒等到回應。"),
 "wb2axip_apbxclk": (W, "apbxclk", "四個單元：從端請求、主端交易、重置同步、回應跨域。", "none", "沒有狀態機，也沒有誤報。", "empty", "沒有輸出：介面樣板不認得 APB。"),
 "wb2axip_axil2apb": (W, "axil2apb", "輸入 skid buffer 群組、讀寫仲裁、回應路徑。", "none", "沒有狀態機，也沒有誤報。", "part", "4 張都只有 AXI 這一側，APB 那一側沒畫。"),
 "wb2axip_aximrd2wbsp": (W, "aximrd2wbsp", "七個單元，回應 FIFO 自成一群。", "none", "沒有狀態機。err_state 是一位元旗標，沒有誤報。", "part", "2 張都是 AR 通道，Wishbone 端與 R 通道沒畫。"),
 "wb2axip_axim2wbsp": (W, "axim2wbsp", "三個單元：讀轉換、寫轉換、Wishbone 仲裁；五個 AXI 通道各自列在左側。", "none", "沒有狀態機，也沒有誤報。", "part", "6 張都在 AXI 請求側，隨機刺激沒有形成完整交易。"),
 "wb2axip_skidbuffer": (W, "skidbuffer", "兩個單元：Skid register 與 Output register。", "none", "沒有狀態機，也沒有誤報。", "full", "6 張，兩個介面各三種情境，是目前最完整的一類。"),
 "wb2axip_axisgfsm": (W, "axisgfsm", "只有兩個單元，模組本身就是一個狀態機。", "good", "sgstate 八個狀態、名稱齊全，通過檢查；執行時走到其中六個。修正前這張被誤擋。", "empty", "沒有輸出：沒認出介面。"),
 "wb2axip_axixbar": (W, "axixbar", "18 個單元，畫的是內部實作，不是「誰接誰」。", "none", "沒有狀態機，也沒有誤報。", "part", "23 張；主從埠是陣列，數值被串成一長串十六進位，難讀。"),
 "serv_serv_top": (V, "serv_top", "11 個單元，連線全畫，無法閱讀。", "miss", "官方文件有指令生命週期圖，我們沒抽到任何狀態機。", "empty", "沒有輸出：沒認出介面。"),
 "serv_serv_rf_top": (V, "serv_rf_top", "三個單元，和官方圖一致。", "miss", "同上，沒抽到。", "empty", "沒有輸出：沒認出介面。"),
 "serv_serv_state": (V, "serv_state", "三個單元：phase_controller、bit_counter、bus_rf_requests。", "miss", "這個模組就是 SERV 的狀態控制，卻沒抽到任何狀態機。它的狀態由計數器加旗標組成。", "empty", "沒有輸出。"),
 "serv_serv_alu": (V, "serv_alu", "三個單元，對應官方電路圖的三個區域。", "none", "沒有狀態機，也沒有誤報。", "empty", "沒有輸出；這是純運算模組，沒有交握介面。"),
 "picorv32_picosoc": (P, "picosoc", "和官方總覽圖對得上，還多畫了位址解碼。", "good", "四個都通過：mem_state、cpu_state、spimemio.state，以及一個計數器型的 recv_state。", "part", "只有一張，而且只有 ser_rx 一條線，幾乎沒有內容。"),
 "picorv32_spimemio": (P, "spimemio", "五個單元，命名直接說明功能。", "good", "13 個狀態全部走到，判定為一致。這是修正後才有的結果。", "part", "一張狀態時序，大半是未知值。"),
 "picorv32_simpleuart": (P, "simpleuart", "四個單元：鮑率設定、接收、發送、接收緩衝。", "counter", "兩個都是計數器，被攤成 11 個與 16 個狀態的鏈。", "part", "4 張；看得到起始位元後 recv_state 前進，但只有開頭幾拍。"),
 "picorv32": (P, "picorv32", "九個單元加一條解碼匯流排，太密。", "good", "mem_state 一致；cpu_state 八個狀態有四個沒走到。", "full", "7 張；記憶體介面的交握有因果箭頭，還帶出 cpu_state。"),
 "dark_darksocv": (D, "darksocv", "和官方圖同一個骨架。", "miss", "內含的 UART 有兩個狀態暫存器，沒抽到。", "empty", "沒有輸出：頂層沒認出介面。"),
 "dark_darkriscv": (D, "darkriscv", "七個單元命名合理，但看不出指令的流向。", "none", "沒有狀態機，也沒有誤報。", "full", "一張指令匯流排的請求與回應，有因果箭頭。"),
 "dark_darkuart": (D, "darkuart", "四個單元：鮑率計時、RX、TX、匯流排介面。", "miss", "RTL 裡有 UART_XSTATE 與 UART_RSTATE 兩個狀態暫存器，都沒抽到。", "empty", "沒有輸出：序列埠沒被認出。"),
 "biriscv_biriscv_lsu": (B, "biriscv_lsu", "四個單元：請求暫存、位址與資料產生、未完成存取控制、載入回應。", "none", "沒有狀態機，也沒有誤報。", "full", "6 張；請求、回應到寫回都有，帶因果箭頭。"),
 "biriscv_biriscv_issue": (B, "biriscv_issue", "只有六個單元，卻因為 139 條連線全畫而變成一團。", "none", "沒有狀態機，也沒有誤報。", "part", "12 張輸入串流，隨機資料，沒有因果箭頭。"),
 "biriscv_biriscv_divider": (B, "biriscv_divider", "四個單元：移位減法、控制、結果快取、寫回。", "none", "沒有狀態機。除法器用計數器控制，這次沒有誤報。", "part", "2 張；valid 拉起後內部沒有反應，等於沒拍到運算。"),
 "verilog-uart_uart_rx": ("alexforencich/verilog-uart", "uart_rx", "四個單元：解串、位元計時、狀態旗標、輸出串流。", "counter", "bit_cnt 是位元計數器，被攤成 11 個狀態。", "full", "14 張；輸出串流的交握完整，另有接收過程的狀態時序。"),
 "verilog-i2c_i2c_master": ("alexforencich/verilog-i2c", "i2c_master", "六個單元，版面拉得很開。", "good", "上層 12 個狀態全部走到；實體層 16 個只走到 7 個；另有一個計數器被當成狀態機。", "part", "2 張命令介面；狀態一直停在 IDLE，多條訊號是未知值。"),
 "biriscv_riscv_core": (B, "biRISC-V 核心", "九個子模組都在；沒有管線階段順序，外框只叫 submodules。", "none", "頂層沒有狀態機，也沒有誤報。", "empty", "沒有輸出：頂層沒認出介面。"),
}
BG = {"clear": ("清楚", "#047857"), "ok": ("尚可", "#b45309"), "messy": ("太亂", "#b91c1c")}
FG = {"good": ("正確", "#047857"), "counter": ("計數器攤開", "#b45309"), "false": ("誤判", "#b91c1c"), "miss": ("漏抓", "#b91c1c"), "none": ("沒有狀態機", "#6b7280")}
TG = {"full": ("情境完整", "#047857"), "part": ("只有片段", "#b45309"), "empty": ("沒有輸出", "#b91c1c")}
ENG = {"busbar": "匯流排長條", "dot": "分層 dot", "hola": "HOLA", "grid": "格狀", "system": "系統圖畫法"}


def put(rel_src, rel_dst):
    dst = os.path.join(OUT, rel_dst)
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copyfile(os.path.join(S, rel_src), dst)
    return rel_dst


def chip(text, color):
    return f'<span class="g" style="background:{color}">{esc(text)}</span>'


rows, secs = [], []
cb, cf, ct = {}, {}, {}
n_eng = n_rt = 0
for d in idx:
    name = d["design"]
    proj, title, brem, fg, frem, tg, trem = EVAL[name]
    blk = json.load(open(os.path.join(S, "all/blk", name, "block.json"), encoding="utf-8"))
    br, engs = blk["bridge"], blk["engines"]
    bk = best[name]
    cross = engs[bk]["cross"]
    bg = "clear" if cross <= 8 else "ok" if cross <= 30 else "messy"
    cb[bg] = cb.get(bg, 0) + 1
    cf[fg] = cf.get(fg, 0) + 1
    ct[tg] = ct.get(tg, 0) + 1
    n_eng += sum(1 for e in engs.values() if e["status"] == "ok")
    n_rt += sum(e.get("roundtrip", 0) for e in engs.values() if e["status"] == "ok")
    order = [bk] + [k for k in ("busbar", "dot", "hola", "grid") if k != bk and engs[k]["status"] == "ok"] + ["system"]
    tabs = "".join(f'<button data-i="{i}" aria-selected="{str(i == 0).lower()}">{ENG[k]}</button>' for i, k in enumerate(order))
    figs = ""
    for i, k in enumerate(order):
        if k == "system":
            src = put(f"all/blk/{name}/x1.system.svg", f"full/blk/{name}/system.svg")
            cap = "專案內建的系統圖畫法。"
        else:
            src = put(f"all/blk/{name}/e3.{k}.svg", f"full/blk/{name}/{k}.svg")
            cap = f"{br['units']} 個單元、{br['unit_nets']} 條連線，{engs[k]['cross']} 個交叉，反查錯誤 {engs[k]['roundtrip']} 個。"
        figs += f'<figure data-i="{i}"{"" if i == 0 else " hidden"}><img loading="lazy" src="{src}" alt="{esc(title)} 的架構圖，{ENG[k]}"><figcaption>{cap}</figcaption></figure>'
    b_html = f'<div class="tabs">{tabs}</div>{figs}'

    if d["fsm"]:
        f_html = '<div class="grid2">'
        for f in d["fsm"]:
            st = "通過" if f["status"] == "ok" else "被拒絕"
            sem = {"consistent": "與執行結果一致", "consistent-subset": "執行結果是它的子集", "semantic-only": "只有執行結果", "mismatch": "與執行結果不一致", "unsupported": "無法檢查"}.get(f["semantic"], f["semantic"] or "")
            reach = f"，執行時走到 {f['reached']} 個" if f.get("reached") is not None else ""
            cap = f"<b>{esc(f['id'])}</b>｜{st}。{f['states']} 個狀態、{f['transitions']} 條轉移{reach}；{sem}。"
            if f["svg"]:
                src = put("all/x4/" + f["svg"], "full/x4/" + f["svg"])
                f_html += f'<figure><img loading="lazy" src="{src}" alt="{esc(f["id"])} 的狀態機圖"><figcaption>{cap}</figcaption></figure>'
            else:
                f_html += f'<figure><div class="empty">沒有圖檔</div><figcaption>{cap}</figcaption></figure>'
        f_html += "</div>"
    else:
        f_html = '<div class="empty">沒有抽出狀態機。</div>'

    if d["timing"]:
        ok = sum(1 for t in d["timing"] if t["ok"])
        t_html = f'<p class="stats">{len(d["timing"])} 張，五項檢查通過 {ok} 張；模擬器 {esc(d["sim"] or "")}。點圖放大。</p><div class="grid3">'
        for t in d["timing"]:
            src = put("all/x4/" + t["svg"], "full/x4/" + t["svg"])
            cap = f"{esc(str(t['interface']))}｜{esc(str(t['protocol']))}，{esc(str(t['scenario']))}"
            t_html += f'<figure><img loading="lazy" src="{src}" alt="{esc(t["id"])} 的時序圖"><figcaption>{cap}</figcaption></figure>'
        t_html += "</div>"
    else:
        t_html = '<div class="empty">沒有產生時序圖。</div>'

    chips = chip("架構圖 " + BG[bg][0], BG[bg][1]) + chip("狀態機 " + FG[fg][0], FG[fg][1]) + chip("時序圖 " + TG[tg][0], TG[tg][1])
    secs.append(f'''<article class="card" id="{esc(name)}"><header><h3>{esc(title)}</h3><span class="proj">{esc(proj)}</span>{chips}</header>
<section><h4>架構圖 {chip(BG[bg][0], BG[bg][1])}</h4><p>{brem}</p>{b_html}</section>
<section><h4>狀態機圖 {chip(FG[fg][0], FG[fg][1])}</h4><p>{frem}</p>{f_html}</section>
<section><h4>時序圖 {chip(TG[tg][0], TG[tg][1])}</h4><p>{trem}</p>{t_html}</section></article>''')
    nf_ok = sum(1 for f in d["fsm"] if f["status"] == "ok")
    rows.append(f'<tr><td><a href="#{esc(name)}">{esc(title)}</a><br><small>{esc(proj)}</small></td>'
                f'<td>{chip(BG[bg][0], BG[bg][1])}<br><small>{br["units"]} 個單元，最佳 {cross} 個交叉</small></td>'
                f'<td>{chip(FG[fg][0], FG[fg][1])}<br><small>抽出 {len(d["fsm"])} 個，通過 {nf_ok} 個</small></td>'
                f'<td>{chip(TG[tg][0], TG[tg][1])}<br><small>{len(d["timing"])} 張</small></td></tr>')

n_fsm = sum(len(d["fsm"]) for d in idx)
n_fsm_ok = sum(1 for d in idx for f in d["fsm"] if f["status"] == "ok")
n_tim = sum(len(d["timing"]) for d in idx)
n_tim_ok = sum(1 for d in idx for t in d["timing"] if t["ok"])
n_tim_des = sum(1 for d in idx if d["timing"])


def bar(counts, table, order):
    tot = sum(counts.values())
    segs = "".join(f'<span style="flex:{counts.get(k, 0)};background:{table[k][1]}" title="{table[k][0]}"></span>' for k in order if counts.get(k))
    legend = "".join(f'<li><b style="color:{table[k][1]}">{counts.get(k, 0)}</b> {table[k][0]}</li>' for k in order if counts.get(k))
    return f'<div class="bar">{segs}</div><ul class="legend">{legend}</ul>', tot


bb, _ = bar(cb, BG, ("clear", "ok", "messy"))
fb, _ = bar(cf, FG, ("good", "counter", "false", "miss", "none"))
tb, _ = bar(ct, TG, ("full", "part", "empty"))

CSS = r"""
:root{--bg:#f3f4f6;--card:#fff;--ink:#14171c;--mute:#5b6370;--line:#d9dde3}
*{box-sizing:border-box}html{scroll-behavior:smooth}
body{margin:0;background:var(--bg);color:var(--ink);font:17px/1.75 "Microsoft JhengHei","Noto Sans TC","PingFang TC",system-ui,sans-serif}
.wrap{max-width:1500px;margin:0 auto;padding:0 24px}
header.hero{background:#0b0d10;color:#fff;padding:52px 0 40px}
.hero h1{font-size:42px;line-height:1.25;margin:0 0 12px}.hero p{font-size:20px;color:#b6bcc6;margin:0 0 20px;max-width:60em}
.hero a{color:#fff}
.chips{display:flex;flex-wrap:wrap;gap:10px}.chip{border:1px solid #3a4049;border-radius:999px;padding:6px 16px;font-size:16px;color:#e6e8eb}.chip b{font-size:20px;margin-right:6px;color:#fff}
h2{font-size:30px;margin:36px 0 16px}
.three{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
.box{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:22px 24px}
.box h3{margin:0 0 12px;font-size:22px}.box ul{margin:10px 0 0;padding-left:1.2em}.box li{margin:.35em 0}
.bar{display:flex;height:18px;border-radius:9px;overflow:hidden;gap:2px}.bar span{display:block}
ul.legend{list-style:none;padding:0;margin:10px 0 0;display:flex;flex-wrap:wrap;gap:4px 18px}ul.legend b{font-size:22px;margin-right:4px}
table{width:100%;border-collapse:collapse;background:var(--card);border:1px solid var(--line);border-radius:14px;overflow:hidden}
th,td{text-align:left;padding:10px 16px;border-bottom:1px solid var(--line);vertical-align:top}th{font-size:16px;color:var(--mute);background:#fafafb}
td small{color:var(--mute);font-size:16px}td a{color:var(--ink);font-weight:700}
.g{display:inline-block;color:#fff;border-radius:999px;padding:1px 12px;font-size:16px;white-space:nowrap}
article.card{background:var(--card);border:1px solid var(--line);border-radius:16px;margin:24px 0;overflow:hidden}
.card>header{display:flex;flex-wrap:wrap;gap:8px 12px;align-items:center;padding:16px 24px;border-bottom:1px solid var(--line);background:#fafafb}
.card h3{font-size:26px;margin:0 8px 0 0}.proj{color:var(--mute);font-size:16px;margin-right:auto}
.card section{padding:18px 24px;border-bottom:1px solid var(--line)}.card section:last-child{border-bottom:0}
.card h4{margin:0 0 4px;font-size:20px;display:flex;gap:10px;align-items:center}.card section>p{margin:0 0 12px}
figure{margin:0 0 12px}figure img{display:block;width:100%;height:auto;max-height:520px;object-fit:contain;background:#fff;border:1px solid var(--line);border-radius:8px;cursor:zoom-in}
figcaption{font-size:16px;color:var(--mute);margin-top:6px}
.grid2{display:grid;grid-template-columns:repeat(2,1fr);gap:16px}.grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
.grid3 figure img{max-height:260px}.grid2 figure img{max-height:420px}
.grid2 figure:only-child{grid-column:1/-1}.grid2 figure:only-child img{max-height:560px}.grid3 figure:only-child{grid-column:span 2}.grid3 figure:only-child img{max-height:360px}
.tabs{display:flex;flex-wrap:wrap;gap:6px;margin:0 0 10px}.tabs button{font:inherit;font-size:16px;border:1px solid var(--line);background:#fff;border-radius:8px;padding:3px 12px;cursor:pointer}
.tabs button[aria-selected=true]{background:#14171c;color:#fff;border-color:#14171c}
.empty{border:2px dashed var(--line);border-radius:10px;padding:22px 20px;text-align:center;color:var(--mute)}
.stats{color:var(--mute);font-size:16px}
footer{padding:30px 0 60px;color:var(--mute);font-size:16px}footer a{color:var(--ink)}
#lb{position:fixed;inset:0;background:rgba(10,12,15,.92);display:none;align-items:center;justify-content:center;z-index:20;cursor:zoom-out;padding:24px}
#lb.on{display:flex}#lb img{max-width:100%;max-height:100%;background:#fff;border-radius:6px}
@media (max-width:1000px){.three,.grid2,.grid3{grid-template-columns:1fr}}
"""
JS = r"""
document.querySelectorAll('.tabs').forEach(t=>t.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{
  const sec=t.closest('section');t.querySelectorAll('button').forEach(x=>x.setAttribute('aria-selected',String(x===b)));
  sec.querySelectorAll('figure[data-i]').forEach(f=>f.hidden=f.dataset.i!==b.dataset.i);})));
const lb=document.getElementById('lb'),lbi=lb.querySelector('img');
document.querySelectorAll('figure img').forEach(i=>i.addEventListener('click',()=>{lbi.src=i.src;lbi.alt=i.alt;lb.classList.add('on');}));
lb.addEventListener('click',()=>lb.classList.remove('on'));
document.addEventListener('keydown',e=>{if(e.key==='Escape')lb.classList.remove('on');});
"""
page = f'''<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>RTL-To-Graph 完整成果</title><style>{CSS}</style></head><body>
<header class="hero"><div class="wrap"><h1>完整成果：30 個設計，三種圖一起看</h1>
<p>每個設計依序列出工具產生的架構圖、狀態機圖、時序圖，三種都給評估。全部用推上 GitHub 的最終版程式重跑。和官方圖的逐組對照在 <a href="index.html">對照圖廊</a>。狀態機另有一套帶證明的做法，結果在 <a href="proof.html">可證明的狀態圖</a>，本頁的狀態機評級是舊做法的結果。</p>
<div class="chips"><span class="chip"><b>{len(idx)}</b>個設計</span><span class="chip"><b>{n_eng}</b>張架構圖，反查錯誤 {n_rt} 個</span><span class="chip"><b>{n_fsm}</b>個狀態機，{n_fsm_ok} 個通過</span><span class="chip"><b>{n_tim}</b>張時序圖，{n_tim_ok} 張通過五項檢查</span></div></div></header>
<main class="wrap">
<h2>評估總覽</h2>
<div class="three">
<div class="box"><h3>架構圖</h3>{bb}<ul><li>30 個設計全部畫得出來，四種排版引擎 {n_eng} 次全部成功，沒有一條線接錯。</li><li>三分之二是清楚的：單元在十個以內、功能單一的模組，命名和連線都讀得懂。</li><li>太亂的五個有共同點：單一大模組的處理器，或內部互連很密的模組。連線全畫、沒有挑重點。</li></ul></div>
<div class="box"><h3>狀態機圖</h3>{fb}<ul><li>有明確狀態暫存器的設計都抽對了，名稱直接取自 RTL。</li><li>三個誤判都是同一種：記錄「已送出、尚未成交」的一位元旗標。</li><li>五個漏抓分兩種：SERV 的狀態由計數器加旗標組成；darkuart 有狀態暫存器卻沒被認出來。</li><li>兩個設計只抽到計數器，被攤成十幾個狀態的鏈。</li></ul></div>
<div class="box"><h3>時序圖</h3>{tb}<ul><li>{n_tim_des} 個設計有輸出，畫出來的 {n_tim} 張都通過檢查：波形可重播、箭頭對得上 RTL 路徑。</li><li>情境完整的五個，介面都很單純：一組請求與回應。</li><li>只有片段的佔一半：每個通道各畫一張，隨機刺激沒有形成完整交易，視窗只有五六拍。</li><li>九個沒有輸出：不認得 APB 與序列埠，或頂層模組沒認出任何介面。</li></ul></div>
</div>
<h2>一起看的結論</h2>
<div class="box"><ul>
<li><b>三種圖的強弱不在同一批設計上。</b>架構圖清楚的 {cb.get("clear", 0)} 個設計裡，時序圖情境完整的只有少數。apbxclk、serv_state、darkuart 的架構圖都清楚，另外兩種圖卻是空的或漏抓。</li>
<li><b>架構圖最穩。</b>它只需要結構，不需要讓電路動起來；狀態機與時序圖要執行或模擬，就會卡在刺激不夠聰明。</li>
<li><b>最大的共同弱點是「挑重點」。</b>架構圖把連線全畫、時序圖把通道全畫、狀態機把計數值全畫，都是同一個問題：有正確的資料，但沒有決定什麼該省略。</li>
<li><b>下一步的優先順序</b>：時序圖的交易層級視窗與會回應的下游模型；狀態機濾掉一位元旗標、把計數鏈摺起來；架構圖依重要度濾線。</li>
</ul></div>
<h2>總表</h2>
<table><thead><tr><th>設計</th><th>架構圖</th><th>狀態機圖</th><th>時序圖</th></tr></thead><tbody>{"".join(rows)}</tbody></table>
<h2>逐一檢視</h2>
{"".join(secs)}
</main>
<footer><div class="wrap">分級方式：架構圖依最佳排版的交叉數，8 個以下為清楚、9 到 30 為尚可、超過 30 為太亂。狀態機與時序圖的分級是 Claude 逐張看圖後的判斷，只有一位評審，不是盲測。<br>
狀態機的「通過」指通過工具自己的結構與語意檢查；這台機器沒有 SymbiYosys，完整性證明沒有跑。時序圖以 iverilog 12.0 模擬。架構圖的單元命名來自 repo 內既有的 teacher 標註，biRISC-V 核心頂層用規則式標註。<br>
產生於 2026 年 11 月 17 日，程式版本為分支 <code>fix/l1-timing-oob-fsm-const</code> 的提交 1692baf。</div></footer>
<div id="lb" role="dialog" aria-label="放大檢視"><img alt=""></div><script>{JS}</script></body></html>'''
io.open(os.path.join(OUT, "all.html"), "w", encoding="utf-8", newline="\n").write(page)
print("wrote all.html", len(page), "| block", cb, "| fsm", cf, "| timing", ct, "| engines", n_eng, "rt", n_rt, "| fsm", n_fsm, n_fsm_ok, "| timing", n_tim, n_tim_ok, n_tim_des)
