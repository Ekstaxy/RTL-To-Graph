"""把迴歸測試與 changelog 套到指定的 repo 根目錄。
    python apply_tests.py <repo_root>"""
import sys
from pathlib import Path

root = Path(sys.argv[1])


def patch(rel, pairs):
    p = root / rel
    raw = p.read_bytes()
    crlf = b"\r\n" in raw
    s = raw.decode("utf-8").replace("\r\n", "\n")
    for old, new in pairs:
        if s.count(old) != 1:
            raise SystemExit(f"{rel}: expected exactly one match, found {s.count(old)}:\n{old[:120]}")
        s = s.replace(old, new)
    if crlf:
        s = s.replace("\n", "\r\n")
    p.write_bytes(s.encode("utf-8"))
    print("patched", rel)


# ── e9：雙檔案的迴歸案例 ──
patch("layers/l1_extract/experiments/e9_protocol_templates/e9_regress.py", [
    ('''def _extra(case: str, sig: dict) -> list[str]:''',
     '''# The clock reaches a child register through an instance connection. The line of that
# connection is in the parent's file: mf_child.v is shorter than that line number (looking it up
# there raised IndexError), and the `~` on it turns the child's posedge into a negedge of clk.
MULTIFILE: dict[str, str] = {
    "mf_top.v": "".join(f"// padding {i}: keeps the instance past the end of mf_child.v\\n"
                        for i in range(8)) + """
module mf_top (input wire clk, input wire d, output wire q);
  mf_child u_inv (.clk(~clk), .d(d), .q(q));
endmodule
""",
    "mf_child.v": """
module mf_child (input wire clk, input wire d, output reg q);
  always @(posedge clk) q <= d;
endmodule
""",
}


def _extra(case: str, sig: dict) -> list[str]:'''),
    ('''def main(argv: list[str] | None = None) -> int:''',
     '''def check_multifile(out: Path, e9) -> list[str]:
    from rtl2d_l1.pipeline import RunConfig, annotate_design

    files = []
    for name, text in MULTIFILE.items():
        f = out / "rtl" / name
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(text.lstrip("\\n") if name != "mf_top.v" else text, encoding="utf-8")
        files.append(str(f))
    cfg = RunConfig(mode="heuristic", targets=frozenset({"block", "fsm", "timing"}))
    run = annotate_design(files, top="mf_top", cfg=cfg, name="mf_top")
    sig = e9.select(run, design="mf_top")
    got = [(c["port"], c["edge"]) for c in sig["clocks"]]
    return [] if got == [("clk", "negedge")] else [f"clocks {got} != [('clk', 'negedge')]"]


def main(argv: list[str] | None = None) -> int:'''),
    ('''    print(f"{len(CASES) - bad}/{len(CASES)} passed")''',
     '''    errs = check_multifile(Path(a.out), e9)
    bad += bool(errs)
    print(f"{'PASS' if not errs else 'FAIL'} multifile" + "".join(f"\\n    {e}" for e in errs))
    print(f"{len(CASES) + 1 - bad}/{len(CASES) + 1} passed")'''),
])

# ── L1：常數解析的單元測試與端到端測試 ──
patch("layers/l1_extract/tests/test_fsm_semantic.py", [
    ('''from rtl2d_l1.frontend.fsm_semantic import detect, state_graph
''',
     '''from rtl2d_l1.frontend.fsm_semantic import _parse_const, detect, state_graph
'''),
    ('''def _graph(tmp_path, name, text):''',
     '''# same machine as BINARY: literals with white space after the base, and comments in front of
# them (both legal Verilog; seen in wb2axip axisgfsm and picosoc spimemio)
SPACED = """
module det(input clk, input rst_n, input x, output y);
  reg [1:0] s, n;
  always @(*) begin
    n = s;
    case (s)
      2'd 0: if (x) n = // leave A
                        2'd 1;
      2'd 1: n = x ? /* stay on the path */ 2'd 2 : 2'b 00;
      2'd 2: if (!x) n = 2'b 0_0;
      default: n = 2'd 0;
    endcase
  end
  always @(posedge clk or negedge rst_n) if (!rst_n) s <= 2'd 0; else s <= n;
  assign y = (s == 2'd 2);
endmodule
"""


def _graph(tmp_path, name, text):'''),
])
p = root / "layers/l1_extract/tests/test_fsm_semantic.py"
raw = p.read_bytes()
nl = "\r\n" if b"\r\n" in raw else "\n"
add = '''

def test_parse_const_accepts_comments_and_space_after_base():
    # text as `str(expr.syntax)` returns it: the comments and newlines in front come with it
    assert _parse_const(" // Clear any errors\\n\\t\\t1'b1") == (1, 1, 1)
    assert _parse_const("/* note */ 2'b1_0") == (2, 2, 3)
    # white space between the base and the digits is legal; `?` bits are don't-care
    assert _parse_const(" 1'b 0") == (0, 1, 1)
    assert _parse_const("\\n\\t3'b 01?") == (2, 3, 0b110)
    assert _parse_const("4 'd 9") == (9, 4, 15)


def test_spaced_and_commented_literals_do_not_make_the_check_unsupported(tmp_path):
    d1, G1, T1 = _graph(tmp_path, "bin", BINARY)
    d2, G2, T2 = _graph(tmp_path, "sp", SPACED)
    f2 = extract_fsms_hybrid(d2, G2, T2)
    assert [getattr(f, "semantic_check", None) for f in f2] == ["consistent"]
    syn = lambda T: {f"{t.canonical_instance}.{r.name}" for t in T for r in t.rows if r.fsm_candidate}  # noqa: E731
    g1 = state_graph([r for r in detect(d1, G1, syn(T1)) if not r.error][0])
    g2 = state_graph([r for r in detect(d2, G2, syn(T2)) if not r.error][0])
    assert nx.is_isomorphic(g1, g2, node_match=lambda a, b: a["reset"] == b["reset"])
'''
s = raw.decode("utf-8").replace("\r\n", "\n").rstrip("\n") + "\n" + add
p.write_bytes(s.replace("\n", nl).encode("utf-8"))
print("appended tests")

# ── changelog ──
patch("layers/l1_extract/docs/CHANGELOG.md", [(
    "# Changelog\n",
    """# Changelog

## Unreleased (2026-11-16)
Bug fixes only; SPEC and `SPEC_VERSION` unchanged.
- `fsm_semantic._parse_const`: constant text read from the syntax tree carries the comments in
  front of the token, and Verilog allows white space between the base and the digits (`1'b 0`,
  `3'b 01?`). Both ended in `semantic_check: unsupported`, which made x4 reject correct FSMs
  (wb2axip `axisgfsm.sgstate` now passes as consistent-subset). Two regression tests.
- e9 `clock_domains._inverted`: the line of an instance connection is now looked up in the file
  of the module that declares the instance. It was looked up in the child's file, which raised
  `IndexError` on multi-file designs (12 of 29 designs in a run over the third-party corpus) or
  silently read an unrelated line. `e9_regress.py` gained a two-file case.
""")])
